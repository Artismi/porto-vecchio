@echo off
rem Avvia Porto Vecchio: un piccolo server locale e il browser. Chiudi la finestra nera per fermarlo.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1"
