# Porto Vecchio — v7 «Inverno»: diario dei lavori e passaggio di consegne

Aggiornato: 3 ottobre 2026, pomeriggio. Base: **v6** (la build fusa: Risacca, abitanti, vita, azioni, economia, tasche). v6 non è stata toccata.
Documento di progetto (visione, fazioni, mappa, decisioni): Claude Doc «Porto Vecchio — progetto di implementazione».

## Come si lavora
- Sorgenti in `v7/src/`, build con `python3 build.py` dentro `v7/` (ricompone `index.html`). Modelli in `v7/assets/`.
- **render.js non si modifica a mano**: si parte da `v6/src/render.js` e si applicano gli script in `tools/` in ordine:
  ```
  cp v6/src/render.js v7/src/render.js
  python3 tools/inverno_render.py  v7/src/render.js   # cielo, luci, grading, neve che cade, nebbia, neve a terra, alberi
  python3 tools/inverno_render2.py v7/src/render.js   # esposizione, mare d'acciaio, facciate e tetti, abeti d'arredo, porto
  python3 tools/inverno_render3.py v7/src/render.js   # paesaggio (Muro, Base, porto cargo, stazioni, beduini, bivacchi, fuochi), leggibilità
  ```
  Ogni script controlla che il pezzo da sostituire esista (se v6 cambia, si ferma e dice cosa non trova).
  Frammenti inclusi dagli script: `tools/snowpass.js` (neve a terra), `tools/alberi.js` (vegetazione), `tools/inverno_paesaggio.js` (paesaggio).
- `world.js` invece è riscritto direttamente in `v7/src/world.js` (la copia di v6 resta in `v6/src/world.js`).
- Prove: `node test_vita.js 2 1`, `node test_azioni.js 1 1`, `node test_economia.js 2 1` dalla cartella `src` (tutte passano con la mappa nuova).
  Screenshot: Chromium senza testa con `--use-gl=angle --use-angle=swiftshader --enable-unsafe-swiftshader`, server http locale,
  `window.__pv` per spostare giocatore, ora (`st.t` in minuti) e zoom (`ui.zoom`), `__pv.R.cam` per spostare subito la camera.

## Fatto
### Mappa nuova (`world.js`) — lingua di terra da ovest a est, 680 × 280 m (340 × 140 caselle)
- Da ovest: **prateria** dei beduini (larga), **foresta** coi villaggi (San Giacomo, Borgo dei Carbonai), **periferia ovest**,
  **centro** su tutta la larghezza, **periferia est**, **il Muro** (x = 556, un solo varco), **la Base** della Tutela, **il porto cargo e militare**.
- **Dorsale come l'Appennino**: nasce nella foresta e corre lungo la mezzeria tra le due costiere, si abbassa e si apre nel centro,
  risale nella periferia est fino al Muro. Quote fino a ~7 m. Funzioni `HILLS`, `ridgeT`, `hillQ`, `ridgeH`.
  Sopra: sentiero di crinale (`crinale_o`, `crinale_e`) come via alternativa, una strada che la scavalca per lato (`collina_o`, `monte`), sentieri dalle costiere.
- **Due costiere** (`nord`, `litoranea`) che seguono la riva: a tratti case tra strada e mare, a tratti la strada sul mare (`onSea`, `coastOff`).
- Centro a isolati (3 vie est-ovest, 5 traverse, il Corso che si apre su Piazza San Rocco), porto vecchio dei pescatori sulla riva sud.
- Periferie: case lungo le costiere e blocchi d'abitazione `block: 'khrush'` (4 piani, da sostituire col modello chruščëvka).
- Base: Rocca, caserma, hangar, depositi, 6 baracche (`use: 'baracca'`). Porto cargo con moli larghi verso est.
- Prateria: stazioni di estrazione Nord e Sud (`miniera`, `stazione2`), saline, Punta col faro. Niente case: è dei beduini.
- **Tutti gli id di luoghi ed edifici di v6 sono rimasti** (gli altri moduli li usano): sono solo spostati. Nuovi luoghi:
  `collina_o, bivacco_o, monolite, campeggio_o, bivacco_e, campeggio_e, covo, muro, varco, eliporto, molo_cargo, villaggio, beduini, stazione_n, stazione_s`.
  I luoghi `camp: 'bivacco' | 'tende' | 'monolite' | 'beduini'` vengono arredati dal render.
- Insegne in **cirillico e coreano** (es. БАР ДЖИНО, 吳 식료품, ДВОРЕЦ КУЛЬТУРЫ, ОПЕКА 보호). L'Emporio di `economia.js` ha ancora l'insegna EMPORIO.
- Esportati in più: `WALL`, `HILLS`, `VILLAGES`, `districtAt(x)`, `yc`, `northY`, `southY`, `onLand`, `SX`, `SY`.
- Numeri: 148 edifici, 115 luoghi, 260 abitanti + 33 del cast, tutto raggiungibile.

### Atmosfera d'inverno (`render.js` via script)
- Cielo grigio-latte, sole pallido senza bande, notte blu-grigia; nebbia più vicina.
- Grading freddo: ombre blu-grigie, mezzitoni spenti, la saturazione resta solo alle luci (neon, fuoco, finestre); compressione dei bianchi.
- Neve che cade (fiocchi, più fitta durante le «piogge» di v6: 22:30-03:00 e 20:00-23:00 del secondo giorno). L'audio della pioggia è ancora quello.
- Neve a terra (`snowPass`): sporca e bagnata dove passa gente (fanghiglia, solchi, impronte, pozzanghere, cumuli grigi a bordo strada),
  candida solo sulle dorsali e nel fitto della foresta, fuliggine al porto cargo e alla Base, **niente neve in prateria** (erba secca e brina).
- Vegetazione: abeti e pini con la neve sui palchi, betulle, alberi spogli; niente palme, olivi, cactus, vigne (le chiamate a `palmTree` disegnano abeti).
- Facciate: intonaci sovietici sbiaditi; tetti sotto la neve; niente persiane liguri. Mare color acciaio.
- Zoom massimo portato a 3.2 (si vedono le due coste); blocchi del terreno caricati fino a 135 m.
- Paesaggio: il Muro (lastre, filo spinato, manifesti del regime, scritte della Risacca, torri coi riflettori che spazzano, varco con garitta e sbarre),
  la Base (radar che gira, antenna rossa, bandiere, eliporto), **l'elicottero** (di giorno a terra, di notte gira sopra Base e periferia est col faro, mai oltre),
  porto cargo (gru, container), stazioni di estrazione (torre di trivella, nastro, carbone, torcia, recinto), accampamento beduino (tende basse color erba secca),
  bivacchi (capanne di tronchi), il monolite, spiazzi con tende, **barili col fuoco** nei luoghi di ritrovo e nei cortili, cartelloni del Garante lungo le costiere.

## Richieste di Andrea ancora da fare (in ordine)
1. **Neve con bordi curvi**, non a quadretti di casella (sfumare la quantità di neve tra caselle, bordi organici).
2. **Segni delle gomme agli incroci** nella neve (archi scuri dove le auto girano).
3. **Più vita alle luci**: insegne, vetrine accese, interni visibili; luci fredde azzurre, neon rosa / ciano / giallo (Miami/cyberpunk) ma sgangherati (tubi rotti, lettere spente, sfarfallio), luci calde, fuoco.
4. **Tetti piatti per la maggior parte, e ci si può salire** (scale esterne, botole: va aggiunto al motore, oggi i tetti non sono percorribili).
5. Profondità e leggibilità: l'occhio deve sapere dove cadere (meno rumore, gerarchia di valori, volumi distinti). In parte fatto; da rivedere a schermo.
6. Modelli da Download da convertire e usare: chruščëvka PSX (`full-modular-soviet-khrushchyovka-psx`, obj), garage sovietici (obj),
   palazzo della cultura di Pripyat (gltf, texture da ridurre a 1K, per `cultura`), recinzione (fbx), casa diroccata (fbx, texture 4K),
   utensili da cucina (gltf), snack retro (fbx), Kenney retro-urban / train / watercraft. Anche i modelli vecchi vanno bene, vanno adattati.
7. **Freddo come sistema** (`popolo.js`): bisogno di calore, stufe come oggetti sociali, barili, vestiti a strati, carbone razionato, mercato nero, legna.
8. **Mettere in ordine**: verbo e oggetto per riordinare e pulire case e covi; il disordine come segno (come il sangue).
9. **Bunker sotterranei**: scavare nelle dorsali (lavoro lungo, terra gelata), da fuori solo una botola, basi nascoste ottime.
10. Fazioni: look della Tutela (fascio-comunista retrofuturista, maschere, pastrani), Risacca partigiana, mafia russa coi tatuaggi leggibili e il capo senza nome
    nella base segreta con 3-5 fidati, beduini metodici. Lo **Squalo va reso anonimo** (in `popolo.js`, `azioni.js`, `game.js` c'è ancora «Squalo»).
11. Modalità a squadre: reclute che muoiono per sempre, solo il protagonista rinasce; il ricambio della popolazione (nascite o arrivi dal regime) c'è già in `azioni.js`.
12. Audio: vento e neve al posto della pioggia.
