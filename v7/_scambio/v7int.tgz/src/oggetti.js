/* Porto Vecchio — Gli Oggetti: un solo catalogo per tutto quello che si tocca (solo logica, nessuna grafica). Caricato dopo soldi.js.
   Prima c'erano tre liste astratte (le merci dell'economia, gli oggetti in tasca, le «risorse» della banda: materiali, attrezzi, viveri).
   Adesso ogni cosa è un oggetto vero, con un prezzo e un peso:
   - CATALOGO: cibo e acqua, legna e carbone, assi e lamiere, viti e cerniere, attrezzi che si consumano, pezzi di radio, carta e inchiostro…
   - BOTTEGHE: ognuna vende quello che vende davvero; il mercato nero quello che non si trova.
   - POSTAZIONI: forgia e incudine, banco del falegname, cucina, forno, macchina da cucire, ciclostile, banco radio… stanno negli interni
     (sono mobili veri) o nelle basi (alcune si costruiscono e si portano via).
   - RICETTE: alcune si fanno ovunque se hai la roba (bende, molotov, panino), altre solo alla postazione giusta e con gli attrezzi giusti.
     Chi lavora produce con le stesse ricette: il fornaio fa il pane con la farina, il fabbro i chiodi col ferro e il carbone. Quello che
     produce lo comprano gli altri; quello che gli serve lo compra da chi lo produce o dalla nave.
   - SMONTARE: la roba vecchia (radio rotte, televisori, rottami d'auto, mobili) si smonta in pezzi utili.
   - FRUGARE: dispense, armadi, cassetti, cassette degli attrezzi, casseforti. Nelle botteghe si ruba dalle scorte vere; in casa d'altri
     c'è il rischio che qualcuno sia in casa. Alcuni sono chiusi a chiave: grimaldello o piede di porco.
   - COSTRUIRE: le strutture e i moduli della banda si pagano in oggetti (assi, lamiere, chiodi, cemento), non in «8 materiali».
   Le vecchie risorse astratte della Risacca restano come CATEGORIE: «materiali» sono assi, lamiere, mattoni…; il resto del gioco le chiede
   ancora così e qui si risponde con gli oggetti veri.
   Si appoggia a Economia (MERCI, SELL, PROD, scorte), Azioni (ITEMS, tasche), Risacca (EXT), Soldi (bancone, casse), Interior (mobili). */
var Oggetti = (function () {
  'use strict';
  const G = typeof Game !== 'undefined' ? Game : require('./game.js');
  const Po = typeof Popolo !== 'undefined' ? Popolo : require('./popolo.js');
  const Az = typeof Azioni !== 'undefined' ? Azioni : require('./azioni.js');
  const Ec = typeof Economia !== 'undefined' ? Economia : require('./economia.js');
  const RS = typeof Risacca !== 'undefined' ? Risacca : require('./risacca.js');
  const So = typeof Soldi !== 'undefined' ? Soldi : (typeof require !== 'undefined' ? require('./soldi.js') : null);
  const INT = typeof Interior !== 'undefined' ? Interior : require('./interiors.js');
  const I = Po._, PLACES = G.PLACES, TS = G.TS;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const dist = (a, b, c, d) => Math.hypot(c - a, d - b);
  const rnd = Math.random, pick = a => a[Math.floor(rnd() * a.length)];
  const r1 = x => Math.round(x * 10) / 10;
  const L = x => `${(Math.round(x * 10) / 10).toLocaleString('it-IT')}.000 lire`;
  const cap = s => s ? s[0].toUpperCase() + s.slice(1) : s;

  // =====================================================================================================================
  // IL CATALOGO
  // [id, nome, prezzo (migliaia di lire), peso (kg), scorta tipica di una bottega, extra]
  // extra: eat {fame, sete, hp, calore, alcol, igiene} · res 'categoria:quanto' (per la Risacca) · tool N (usi prima di rompersi)
  //        st 'postazione' (si piazza in una base e fa da postazione) · imp (arriva con la nave) · ill (illegale) · wpn (arma del motore)
  //        heat (calore che dà bruciando, ore di stufa) · empty (contenitore vuoto: in cosa si trasforma una volta usato)
  // =====================================================================================================================
  const CAT = {};
  const GROUPS = {};
  function grp(cat, label, rows) { GROUPS[cat] = label; rows.forEach(([id, nome, prezzo, peso, q, ex]) => { CAT[id] = Object.assign({ id, nome, cat, prezzo, peso, q: q || 0 }, ex || {}); }); }

  grp('cibo', 'Da mangiare', [
    ['pane', 'pane', 1, .5, 30, { eat: { fame: .25 }, res: 'viveri:.5' }],
    ['focaccia', 'focaccia', 1.5, .4, 12, { eat: { fame: .3 }, res: 'viveri:.5' }],
    ['biscotti', 'pacco di biscotti', 1.5, .4, 15, { eat: { fame: .15 }, res: 'viveri:.5', imp: 1 }],
    ['gallette', 'gallette del soldato', 1, .3, 10, { eat: { fame: .2 }, res: 'viveri:1', imp: 1 }],
    ['verdura', 'verdura', 1.5, 1, 30, { eat: { fame: .1 }, res: 'viveri:.5' }],
    ['patate', 'sacchetto di patate', 1.5, 2, 25, { res: 'viveri:1' }],
    ['pomodori', 'pomodori', 1.5, 1, 20, { eat: { fame: .08, sete: -.05 }, res: 'viveri:.5' }],
    ['cipolle', 'cipolle', 1, 1, 15, { res: 'viveri:.3' }],
    ['frutta', 'frutta', 1.5, 1, 25, { eat: { fame: .1, sete: -.08 }, res: 'viveri:.5' }],
    ['limoni', 'limoni', 1, .5, 10, {}],
    ['olive', 'olive', 2, 1, 6, { eat: { fame: .05 } }],
    ['uova', 'mezza dozzina di uova', 1.5, .4, 15, { res: 'viveri:.5' }],
    ['latte', 'litro di latte', 1, 1, 20, { eat: { fame: .08, sete: -.2 }, res: 'viveri:.5' }],
    ['formaggio', 'forma di formaggio', 3, .5, 10, { eat: { fame: .25 }, res: 'viveri:1' }],
    ['carne', 'carne fresca', 5, .5, 15, { res: 'viveri:1' }],
    ['salsiccia', 'salsiccia', 3, .4, 10, { res: 'viveri:1' }],
    ['salame', 'salame', 4, .4, 8, { eat: { fame: .3 }, res: 'viveri:1.5' }],
    ['pesce', 'pesce fresco', 4, .6, 15, { res: 'viveri:1' }],
    ['sarde', 'sarde', 2, .5, 12, { res: 'viveri:.5' }],
    ['polpo', 'polpo', 4, .8, 4, { res: 'viveri:1' }],
    ['scatolame', 'scatoletta di tonno', 2, .25, 30, { eat: { fame: .2 }, res: 'viveri:1', empty: 'latta_vuota' }],
    ['carne_scatola', 'carne in scatola', 2.5, .35, 15, { eat: { fame: .3 }, res: 'viveri:1', imp: 1, empty: 'latta_vuota' }],
    ['legumi', 'fagioli in scatola', 1.5, .4, 15, { eat: { fame: .25 }, res: 'viveri:1', imp: 1, empty: 'latta_vuota' }],
    ['conserva', 'barattolo di conserva', 2, .6, 8, { eat: { fame: .25 }, res: 'viveri:1.5', empty: 'barattolo' }],
    ['razione', 'pacco viveri', 8, 2.5, 0, { eat: { fame: .6 }, res: 'viveri:4' }],
    ['panino', 'panino imbottito', 2.5, .3, 10, { eat: { fame: .45 }, res: 'viveri:1' }],
    ['pasto', 'piatto caldo', 4, .6, 12, { eat: { fame: .75, calore: .15 } }],
    ['minestra', 'gavetta di minestra', 2, .8, 0, { eat: { fame: .5, sete: -.15, calore: .25 }, res: 'viveri:1' }],
    ['gelato', 'gelato', 1.5, .2, 10, { eat: { fame: .05, sete: -.05 } }],
    ['miele', 'barattolo di miele', 4, .5, 4, { eat: { fame: .15 }, res: 'viveri:.5' }],
    ['cioccolato', 'tavoletta di cioccolato', 2, .1, 10, { eat: { fame: .15, hp: 2 }, imp: 1 }],
  ]);
  grp('bevande', 'Da bere', [
    ['acqua', 'bottiglia d\'acqua', .5, 1, 30, { eat: { sete: -.45 }, empty: 'bottiglia_vuota' }],
    ['tanica_acqua', 'tanica d\'acqua (10 l)', 2, 10.5, 0, { eat: { sete: -.5 }, res: 'viveri:2', uses: 10, empty: 'tanica_vuota' }],
    ['acqua_pozzo', 'acqua di cisterna (da bollire)', 0, 1, 0, { empty: 'bottiglia_vuota' }],
    ['caffe_tazza', 'tazzina di caffè', 1, .1, 0, { eat: { sonno: -.15, calore: .05 } }],
    ['thermos', 'thermos di caffè', 4, 1.2, 0, { eat: { sonno: -.3, calore: .2 }, uses: 4 }],
    ['te', 'tè caldo', 1, .3, 0, { eat: { sete: -.3, calore: .2 } }],
    ['vino', 'bottiglia di vino', 2, 1.2, 20, { eat: { sete: -.1, alcol: .35, calore: .1 }, empty: 'bottiglia_vuota' }],
    ['birra', 'birra', 1.5, .7, 25, { eat: { sete: -.25, alcol: .2 }, empty: 'bottiglia_vuota', imp: 1 }],
    ['grappa', 'grappa', 5, .8, 8, { eat: { alcol: .6, calore: .3 }, empty: 'bottiglia_vuota' }],
    ['whisky', 'whisky di contrabbando', 18, 1, 3, { eat: { alcol: .6, calore: .2 }, empty: 'bottiglia_vuota', imp: 1 }],
    ['aranciata', 'aranciata', 1, .4, 15, { eat: { sete: -.35 }, empty: 'bottiglia_vuota', imp: 1 }],
  ]);
  grp('dispensa', 'Dispensa e ingredienti', [
    ['farina', 'sacco di farina (5 kg)', 3, 5, 20, { imp: 1, res: 'viveri:1' }],
    ['pasta', 'pacco di pasta', 1.5, 1, 30, { imp: 1, res: 'viveri:1' }],
    ['riso', 'pacco di riso', 2, 1, 15, { imp: 1, res: 'viveri:1' }],
    ['passata', 'bottiglia di passata', 1.5, .7, 15, {}],
    ['olio', 'olio d\'oliva', 4, 1, 10, {}],
    ['sale', 'sale', .5, 1, 15, {}],
    ['zucchero', 'zucchero', 2, 1, 15, { imp: 1, res: 'zucchero:1' }],
    ['caffe', 'caffè macinato', 3, .25, 15, { imp: 1 }],
    ['te_foglie', 'tè in foglie', 2, .1, 6, { imp: 1 }],
    ['lievito', 'lievito', .5, .05, 10, { imp: 1 }],
    ['strutto', 'strutto', 1.5, .5, 6, {}],
    ['capi', 'capo di bestiame', 30, 40, 4, {}],
    ['uva', 'cassetta d\'uva', 2, 5, 0, {}],
  ]);
  grp('combustibili', 'Fuoco e calore', [
    ['legna', 'fascio di legna da ardere', 1.5, 8, 20, { heat: 3, res: 'materiali:.3' }],
    ['carbone', 'sacco di carbone', 3, 10, 15, { heat: 8 }],
    ['carbonella', 'carbonella', 2, 4, 6, { heat: 4 }],
    ['benzina', 'tanica di benzina', 4, 6, 25, { res: 'benzina:1', empty: 'tanica_vuota' }],
    ['gasolio', 'tanica di gasolio', 3.5, 6, 10, { heat: 10, empty: 'tanica_vuota' }],
    ['bombola', 'bombola del gas', 12, 15, 6, { imp: 1, heat: 12 }],
    ['fiammiferi', 'scatola di fiammiferi', .2, .05, 30, {}],
    ['accendino', 'accendino', 1, .05, 15, { imp: 1 }],
    ['candele', 'pacco di candele', 1, .3, 20, {}],
    ['alcol', 'alcol denaturato', 1.5, 1, 10, { imp: 1 }],
    ['olio_motore', 'latta d\'olio motore', 4, 2, 8, { imp: 1 }],
  ]);
  grp('edilizia', 'Legname e muratura', [
    ['legno', 'tronco', 2, 25, 15, { res: 'materiali:1' }],
    ['assi', 'fascio di assi', 4, 12, 15, { res: 'materiali:1' }],
    ['travi', 'trave', 5, 20, 6, { res: 'materiali:1.5' }],
    ['compensato', 'pannello di compensato', 4, 8, 8, { res: 'materiali:1', imp: 1 }],
    ['sughero', 'sughero', 1, 2, 6, {}],
    ['mattoni', 'pallet di mattoni (40)', 8, 50, 6, { res: 'materiali:2' }],
    ['cemento', 'sacco di cemento', 4, 25, 10, { res: 'materiali:1', imp: 1 }],
    ['sabbia', 'sacco di sabbia', .5, 25, 15, { res: 'materiali:.5' }],
    ['ghiaia', 'sacco di ghiaia', .5, 25, 10, { res: 'materiali:.5' }],
    ['pietre', 'pietre', .5, 30, 8, { res: 'materiali:.5' }],
    ['malta', 'secchio di malta', 0, 20, 0, { res: 'materiali:1' }],
    ['sacco_sabbia', 'sacchetto di sabbia (riparo)', 0, 25, 0, { res: 'materiali:.5' }],
    ['lamiera', 'lamiera ondulata', 6, 10, 10, { res: 'materiali:1.5', imp: 1 }],
    ['tondino', 'tondino di ferro', 3, 8, 10, { res: 'materiali:1', imp: 1 }],
    ['ferro', 'barre di ferro', 3, 8, 10, { res: 'materiali:1', imp: 1 }],
    ['latta', 'lamierino da latte', 3, 4, 8, { imp: 1 }],
    ['rete', 'rotolo di rete metallica', 6, 12, 6, { res: 'materiali:1', imp: 1 }],
    ['filo_spinato', 'rotolo di filo spinato', 8, 10, 4, { res: 'materiali:1', imp: 1 }],
    ['telo', 'telo cerato', 4, 3, 8, { res: 'materiali:.5', imp: 1 }],
    ['vetro', 'lastra di vetro', 5, 6, 4, { imp: 1 }],
    ['tubi', 'tubi di ferro', 4, 6, 8, { res: 'materiali:1', imp: 1 }],
    ['tubo_stufa', 'tubo da stufa', 3, 3, 4, {}],
  ]);
  grp('ferramenta', 'Ferramenta', [
    ['chiodi', 'scatola di chiodi', 1, .5, 20, { res: 'materiali:.3' }],
    ['viti', 'scatola di viti', 1.5, .4, 15, { imp: 1, res: 'materiali:.3' }],
    ['bulloni', 'bulloni e dadi', 2, .8, 12, { imp: 1, res: 'materiali:.3' }],
    ['cerniere', 'paio di cerniere', 1.5, .4, 10, {}],
    ['lucchetto', 'lucchetto', 3, .3, 10, { imp: 1 }],
    ['catena', 'catena', 4, 3, 6, {}],
    ['filo_ferro', 'rotolo di filo di ferro', 1.5, 1, 12, {}],
    ['corda', 'corda', 2, 1.5, 12, {}],
    ['nastro', 'nastro isolante', 1, .1, 15, { imp: 1 }],
    ['colla', 'colla', 2, .3, 10, { imp: 1 }],
    ['sacchi', 'sacchi di iuta', 1, .5, 20, {}],
    ['secchio', 'secchio', 2, 1, 8, {}],
    ['vernice', 'barattolo di vernice', 5, 3, 6, { imp: 1, res: 'vernice:1' }],
    ['bomboletta', 'bomboletta spray', 3, .4, 10, { imp: 1, res: 'vernice:1' }],
    ['gesso', 'gessetti', .5, .1, 15, { res: 'gesso:1' }],
    ['tanica_vuota', 'tanica vuota', 2, .5, 8, {}],
    ['guanti', 'guanti da lavoro', 1.5, .2, 10, {}],
  ]);
  grp('attrezzi', 'Attrezzi', [
    ['martello', 'martello', 4, 1, 6, { tool: 200, res: 'attrezzi:.5' }],
    ['cacciavite', 'cacciaviti', 2, .3, 8, { tool: 200, imp: 1, res: 'attrezzi:.3' }],
    ['pinze', 'pinze', 3, .4, 6, { tool: 200, imp: 1, res: 'attrezzi:.3' }],
    ['tronchesi', 'tronchesi', 4, .6, 5, { tool: 150, imp: 1, res: 'attrezzi:.5' }],
    ['chiave_inglese', 'chiave inglese', 4, .8, 5, { tool: 300, imp: 1, res: 'attrezzi:.3' }],
    ['seghetto', 'seghetto per metalli', 3, .5, 5, { tool: 80, imp: 1, res: 'attrezzi:.3' }],
    ['sega', 'sega da legno', 5, 1, 5, { tool: 120, res: 'attrezzi:.5' }],
    ['ascia', 'ascia', 6, 2, 4, { tool: 150, res: 'attrezzi:.5' }],
    ['lima', 'lima', 2, .3, 4, { tool: 100, res: 'attrezzi:.2' }],
    ['trapano', 'trapano a mano', 8, 1.5, 3, { tool: 150, imp: 1, res: 'attrezzi:.5' }],
    ['taglierino', 'taglierino', 1, .1, 10, { tool: 60, imp: 1 }],
    ['forbici', 'forbici', 2, .2, 8, { tool: 150 }],
    ['cazzuola', 'cazzuola', 2, .5, 4, { tool: 200 }],
    ['pala', 'pala', 6, 2.5, 4, { tool: 300, res: 'attrezzi:.5' }],
    ['piccone', 'piccone', 7, 3, 3, { tool: 200, res: 'attrezzi:.5' }],
    ['piede', 'piede di porco', 4, 2, 4, { tool: 250, res: 'attrezzi:1' }],
    ['grimaldello', 'grimaldelli', 6, .1, 0, { tool: 25, ill: 1 }],
    ['carriola', 'carriola', 15, 15, 2, { tool: 500 }],
    ['saldatore', 'saldatore a stagno', 8, .5, 3, { tool: 120, imp: 1, res: 'radio:.5' }],
    ['stagno', 'rocchetto di stagno', 2, .1, 6, { imp: 1, res: 'radio:.2' }],
    ['pentola', 'pentola', 4, 1.5, 6, { tool: 500 }],
    ['padella', 'padella', 3, 1, 6, { tool: 500 }],
    ['moka', 'moka', 4, .5, 6, { tool: 300, imp: 1 }],
    ['ferri_maglia', 'ferri da maglia', 1, .1, 4, { tool: 300 }],
    ['ago_filo', 'ago e filo', .5, .05, 12, { tool: 40 }],
    ['rete_pesca', 'rete da pesca', 10, 4, 3, { tool: 100 }],
    ['canna', 'canna da pesca', 5, 1, 4, { tool: 150 }],
    ['torcia', 'torcia elettrica', 4, .5, 8, { imp: 1, tool: 300 }],
  ]);
  grp('elettrico', 'Elettricità e radio', [
    ['pile', 'pile', 2, .2, 15, { imp: 1, res: 'radio:.3' }],
    ['lampadine', 'lampadine', 2, .1, 10, { imp: 1 }],
    ['cavo', 'matassa di cavo elettrico', 3, 1, 10, { imp: 1, res: 'radio:.3' }],
    ['cavo_coax', 'cavo coassiale', 4, 1, 4, { imp: 1, res: 'radio:.5' }],
    ['valvole', 'valvole', 6, .2, 6, { imp: 1, res: 'radio:1' }],
    ['transistor', 'transistor e condensatori', 4, .1, 6, { imp: 1, res: 'radio:.5' }],
    ['altoparlante', 'altoparlante', 4, .8, 4, { imp: 1, res: 'radio:.5' }],
    ['batteria_auto', 'batteria d\'auto', 12, 14, 4, { imp: 1, res: 'radio:1' }],
    ['sveglia', 'sveglia', 3, .4, 6, { imp: 1 }],
    ['interruttore', 'interruttori e fusibili', 1, .1, 10, { imp: 1 }],
    ['radiolina', 'radio a transistor', 15, 1, 4, { imp: 1 }],
    ['ricetrasmittente', 'ricetrasmittente', 0, 4, 0, { res: 'radio:4', ill: 1 }],
    ['antenna_kit', 'antenna smontabile', 0, 6, 0, { res: 'radio:2' }],
    ['disturbatore', 'disturbatore di frequenze', 0, 3, 0, { ill: 1 }],
    ['timer', 'timer a orologeria', 0, .5, 0, { ill: 1 }],
    ['telefono', 'cellulare', 30, .8, 2, { imp: 1, res: 'telefono:1' }],
    ['fotocamera', 'macchina fotografica', 25, .8, 2, { imp: 1, res: 'fotocamera:1' }],
    ['rullino', 'rullino', 2, .05, 8, { imp: 1 }],
    ['cassetta', 'audiocassetta', 1.5, .1, 10, { imp: 1 }],
  ]);
  grp('stampa', 'Carta e stampa', [
    ['carta', 'risma di carta', 2, 2.5, 20, { imp: 1, res: 'carta:1' }],
    ['cartoncino', 'cartoncino', 1, .5, 8, { imp: 1 }],
    ['inchiostro', 'flacone d\'inchiostro', 3, .3, 8, { imp: 1, res: 'inchiostro:1' }],
    ['penne', 'penne e matite', .5, .05, 15, {}],
    ['quaderno', 'quaderno', .5, .2, 15, {}],
    ['buste', 'buste e francobolli', .5, .05, 15, {}],
    ['carta_bollata', 'carta bollata', 2, .05, 10, {}],
    ['giornale', 'giornale del Garante', .3, .2, 20, {}],
    ['volantini', 'pacco di volantini', 0, 1.5, 0, { res: 'volantini:10', ill: 1 }],
    ['poster', 'manifesti clandestini', 0, .8, 0, { ill: 1 }],
    ['libretto', 'libretti clandestini', 0, .3, 0, { ill: 1 }],
    ['stencil', 'stencil di cartone', 0, .1, 0, { tool: 30 }],
    ['timbro_falso', 'timbro falso dell\'Ufficio Rettifiche', 0, .2, 0, { tool: 20, ill: 1 }],
    ['foto_tessera', 'foto tessera', 0, .01, 0, {}],
    ['documenti', 'lasciapassare falso', 0, .05, 0, { res: 'documenti:1', ill: 1 }],
    ['prove', 'foto compromettenti', 0, .05, 0, { res: 'prove:1' }],
    ['fascicolo', 'fascicolo della Tutela', 0, .4, 0, { ill: 1 }],
    ['moduli', 'moduli in bianco con lo stemma', 0, .1, 0, {}],
  ]);
  grp('medicina', 'Medicine', [
    ['medicine', 'scatola di aspirine', 3, .1, 10, { eat: { hp: 6 }, imp: 1, res: 'medicine:.5' }],
    ['antibiotici', 'antibiotici', 8, .1, 4, { eat: { hp: 15 }, imp: 1, res: 'medicine:1.5' }],
    ['garze', 'garze', 1, .1, 10, { imp: 1, res: 'medicine:.3' }],
    ['bende', 'bende', 1.5, .2, 10, { eat: { hp: 10 }, res: 'medicine:.5' }],
    ['cerotti', 'cerotti', .5, .05, 10, { eat: { hp: 3 }, imp: 1 }],
    ['disinfettante', 'disinfettante', 2, .5, 8, { res: 'medicine:.5' }],
    ['siringhe', 'siringhe', 2, .1, 6, { imp: 1 }],
    ['morfina', 'fiale di morfina', 20, .05, 0, { eat: { hp: 25 }, ill: 1, res: 'medicine:2' }],
    ['kit_medico', 'cassetta del pronto soccorso', 0, 1.5, 0, { eat: { hp: 40 }, res: 'medicine:3' }],
  ]);
  grp('igiene', 'Casa e igiene', [
    ['sapone', 'saponetta', 1, .15, 15, { eat: { igiene: -.4 } }],
    ['detersivo', 'detersivo', 2, 1, 8, { imp: 1 }],
    ['candeggina', 'candeggina', 1.5, 1, 6, { imp: 1 }],
    ['spugne', 'spugne', 1, .05, 10, {}],
    ['dentifricio', 'dentifricio', 1, .1, 10, { imp: 1 }],
    ['rasoio', 'rasoio e lamette', 2, .1, 8, { imp: 1 }],
    ['stracci', 'stracci', 0, .3, 0, {}],
    ['bottiglia_vuota', 'bottiglia vuota', 0, .4, 0, {}],
    ['barattolo', 'barattolo vuoto', 0, .2, 0, {}],
    ['latta_vuota', 'latta vuota', 0, .05, 0, {}],
    ['cartone', 'cartone', 0, .5, 0, {}],
  ]);
  grp('vestiti', 'Vestiti', [
    ['stoffa', 'pezza di stoffa', 3, 1, 10, { imp: 1 }],
    ['stoffa_grigia', 'panno grigio da divisa', 5, 1, 0, { ill: 1 }],
    ['lana', 'matassa di lana', 2, .5, 8, {}],
    ['pelle', 'pelle conciata', 6, 2, 3, {}],
    ['bottoni', 'bottoni', .5, .05, 10, {}],
    ['vestiti', 'vestiti', 8, 1.5, 6, { calore: .2 }],
    ['maglione', 'maglione di lana', 8, .8, 6, { calore: .3 }],
    ['cappotto', 'cappotto', 20, 2.5, 4, { calore: .5 }],
    ['scarpe', 'scarponi', 12, 1.5, 4, { calore: .1 }],
    ['guanti_lana', 'guanti di lana', 2, .1, 8, { calore: .1 }],
    ['passamontagna', 'passamontagna', 2, .1, 4, { calore: .1, mask: 1 }],
    ['zaino', 'zaino militare', 8, 1, 4, { bag: 20, imp: 1 }],
    ['coperta', 'coperta', 5, 2, 8, { calore: .3, res: 'mobili:.3' }],
    ['lenzuola', 'lenzuola', 3, 1, 6, {}],
    ['divisa', 'divisa dei Grigi', 0, 2, 0, { ill: 1, res: 'divisa:1' }],
  ]);
  grp('arredi', 'Arredi e postazioni', [
    ['mobili', 'mobile usato', 12, 30, 3, { res: 'mobili:1' }],
    ['sedia', 'sedia', 4, 4, 4, { res: 'mobili:.5' }],
    ['tavolo', 'tavolo', 10, 20, 2, { res: 'mobili:1' }],
    ['branda', 'branda', 8, 10, 2, { res: 'mobili:1' }],
    ['materasso', 'materasso', 10, 12, 2, { res: 'mobili:1' }],
    ['scaffale', 'scaffale', 8, 15, 2, { res: 'mobili:1' }],
    ['casse', 'cassa di legno', 3, 5, 8, { res: 'materiali:.5' }],
    ['barricata', 'pannelli da barricata', 0, 20, 0, { res: 'materiali:3' }],
    ['porta_rinforzata', 'porta rinforzata', 0, 40, 0, {}],
    ['botola', 'botola mimetizzata', 0, 25, 0, {}],
    ['stufa', 'stufa a legna', 25, 40, 2, { st: 'stufa' }],
    ['fornello', 'fornello da campo', 10, 3, 4, { st: 'cucina', imp: 1 }],
    ['banco', 'banco da lavoro smontabile', 0, 25, 0, { st: 'banco_lavoro' }],
    ['macchina_cucire', 'macchina da cucire', 40, 12, 1, { st: 'macchina_cucire', imp: 1 }],
    ['ciclostile', 'ciclostile', 60, 20, 0, { st: 'ciclostile', ill: 1 }],
    ['banco_radio', 'banco radio portatile', 0, 10, 0, { st: 'banco_radio' }],
    ['alambicco', 'alambicco di rame', 0, 12, 0, { st: 'alambicco', ill: 1 }],
    ['ingranditore', 'ingranditore e bacinelle', 30, 8, 0, { st: 'camera_oscura', imp: 1 }],
  ]);
  grp('armi', 'Armi e sabotaggio', [
    ['coltello', 'coltello', 4, .3, 4, { tool: 400, wpn: 'coltello' }],
    ['pistola', 'pistola', 60, 1, 0, { ill: 1, wpn: 'pistola' }],
    ['lupara', 'lupara', 50, 3, 0, { ill: 1, wpn: 'lupara' }],
    ['mitra', 'mitra', 120, 3.5, 0, { ill: 1, wpn: 'mitra' }],
    ['munizioni', 'scatola di munizioni', 6, .5, 0, { ill: 1 }],
    ['molotov', 'molotov', 0, 1, 0, { ill: 1, wpn: 'molotov' }],
    ['triboli', 'triboli (chiodi a tre punte)', 0, 1, 0, { ill: 1 }],
    ['kit', 'kit di sabotaggio', 0, 2, 0, { ill: 1, res: 'kit:1' }],
    ['manette', 'manette', 0, .4, 0, {}],
  ]);
  grp('valori', 'Valori e contrabbando', [
    ['sigarette', 'stecca di sigarette', 2, .2, 30, { res: 'merce:.2' }],
    ['sigarette_contr', 'sigarette di contrabbando', 4, .2, 0, { ill: 1, res: 'merce:.5' }],
    ['tabacco', 'tabacco e cartine', 1, .05, 10, {}],
    ['carte', 'mazzo di carte', 2, .1, 6, {}],
    ['orologio', 'orologio', 15, .1, 0, {}],
    ['gioielli', 'gioielli', 40, .1, 0, {}],
    ['valuta', 'dollari dell\'Impero', 30, .01, 0, { ill: 1 }],
    ['merce', 'cassa di merce di contrabbando', 15, 10, 0, { ill: 1, res: 'merce:1' }],
    ['roba', 'roba', 8, .05, 0, { ill: 1 }],
    ['refurtiva', 'refurtiva', 6, 2, 0, { ill: 1 }],
  ]);
  grp('rottami', 'Roba vecchia e rottami', [
    ['rottami', 'rottami di ferro', .5, 10, 0, { res: 'materiali:.5' }],
    ['radio_rotta', 'radio rotta', 0, 4, 0, {}],
    ['tv_rotta', 'televisore rotto', 0, 15, 0, {}],
    ['elettrodomestico', 'elettrodomestico rotto', 0, 25, 0, {}],
    ['mobile_rotto', 'mobile sfasciato', 0, 15, 0, {}],
    ['ricambi', 'pezzi d\'auto', 2, 6, 0, {}],
    ['pneumatico', 'pneumatico', 6, 9, 4, { imp: 1 }],
  ]);

  // le categorie della Risacca: quanti «pezzi» di quella risorsa vale ogni oggetto
  const RESOF = {};   // res -> [[id, quanto]]
  Object.values(CAT).forEach(o => { if (!o.res) return; const [r, k] = o.res.split(':'); o.resK = r; o.resV = +k || 1; (RESOF[r] = RESOF[r] || []).push([o.id, o.resV]); });
  // i sinonimi per i messaggi della chat («portami delle assi»)
  const NAMEIDX = Object.values(CAT).map(o => [o.id, norm(o.nome)]);
  function norm(s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[«»"']/g, ' ').trim(); }
  const nm = id => (CAT[id] ? CAT[id].nome : id);
  function alts(key) { return key.split('|'); }
  const isItem = id => !!CAT[id];

  // =====================================================================================================================
  // LE POSTAZIONI
  // model: il mobile negli interni (st_* li disegna oggetti_ui.js, gli altri sono del kit di mobili). rooms: dove si trovano.
  // Un mobile del kit può già essere una postazione (la cucina di casa, il lavandino per l'acqua, le botti della cantina).
  // =====================================================================================================================
  const STATIONS = {
    cucina:          { nome: 'cucina', model: 'kitchenStove' },
    acqua:           { nome: 'acqua corrente', model: 'kitchenSink' },
    forno:           { nome: 'forno a legna', model: 'st_forno' },
    forgia:          { nome: 'forgia e incudine', model: 'st_forgia' },
    saldatrice:      { nome: 'saldatrice', model: 'st_saldatrice' },
    banco_lavoro:    { nome: 'banco da lavoro', model: 'pv_banco_lavoro' },
    banco_falegname: { nome: 'banco del falegname', model: 'st_banco_falegname' },
    banco_macellaio: { nome: 'banco del macellaio', model: 'st_banco_macellaio' },
    macchina_cucire: { nome: 'macchina da cucire', model: 'st_macchina_cucire' },
    ciclostile:      { nome: 'ciclostile', model: 'st_ciclostile' },
    banco_radio:     { nome: 'banco radio', model: 'st_banco_radio' },
    camera_oscura:   { nome: 'camera oscura', model: 'st_camera_oscura' },
    tavolo_medico:   { nome: 'tavolo medico', model: 'st_tavolo_medico' },
    alambicco:       { nome: 'alambicco', model: 'st_alambicco' },
    stufa:           { nome: 'stufa', model: 'st_stufa' },
    botti:           { nome: 'botti della cantina', model: 'fd_barrel' },
    linea:           { nome: 'linea delle conserve', model: 'fx_conveyor-long' },
  };
  // i mobili del kit che fanno già da postazione
  const FURN2ST = { pv_banco_lavoro: 'banco_lavoro', pv_ponte: 'banco_lavoro', kitchenStove: 'cucina', kitchenSink: 'acqua', bathroomSink: 'acqua', fd_barrel: 'botti', 'fx_conveyor-long': 'linea', 'fx_machine': 'linea' };
  Object.entries(STATIONS).forEach(([k, s]) => { s.id = k; if (s.model.startsWith('st_')) FURN2ST[s.model] = k; });

  // =====================================================================================================================
  // LE RICETTE
  // in: {oggetto: quanti} — «a|b» vuol dire uno qualsiasi dei due. tools: attrezzi che servono (si consumano un po', non spariscono).
  // st: postazione (o «a|b»), null = ovunque. min: minuti di lavoro. place: solo in certi luoghi (estrarre, raccogliere).
  // kind: 'fai' (fabbricare), 'cucina', 'smonta', 'raccogli'. job: chi la fa per mestiere (per la produzione degli abitanti).
  // =====================================================================================================================
  const RECIPES = {};
  function rc(id, nome, out, inp, o) { RECIPES[id] = Object.assign({ id, nome, out, in: inp || {}, tools: [], st: null, min: 30, kind: 'fai' }, o || {}); }
  // ---- cucina ----
  rc('pasto_pasta', 'pasta al sugo (3 piatti)', { pasto: 3 }, { pasta: 1, 'passata|pomodori': 1 }, { st: 'cucina|stufa', tools: ['pentola'], min: 30, kind: 'cucina' });
  rc('pasto_minestra', 'minestra di verdure (4 gavette)', { minestra: 4 }, { verdura: 2, patate: 1 }, { st: 'cucina|stufa', tools: ['pentola'], min: 60, kind: 'cucina' });
  rc('pasto_pesce', 'pesce fritto (3 piatti)', { pasto: 3 }, { 'pesce|sarde': 2, olio: 1 }, { st: 'cucina', tools: ['padella'], min: 30, kind: 'cucina' });
  rc('pasto_carne', 'carne e patate (3 piatti)', { pasto: 3 }, { 'carne|salsiccia': 2, patate: 1 }, { st: 'cucina', tools: ['padella'], min: 45, kind: 'cucina' });
  rc('pasto_riso', 'riso e verdure (3 piatti)', { pasto: 3 }, { riso: 1, 'verdura|pomodori|legumi': 1 }, { st: 'cucina|stufa', tools: ['pentola'], min: 30, kind: 'cucina' });
  rc('caffe', 'caffè con la moka (4 tazzine)', { caffe_tazza: 4 }, { caffe: 1 }, { st: 'cucina|stufa', tools: ['moka'], min: 10, kind: 'cucina' });
  rc('thermos', 'thermos di caffè', { thermos: 1 }, { caffe: 1, bottiglia_vuota: 1 }, { st: 'cucina|stufa', tools: ['moka'], min: 15, kind: 'cucina' });
  rc('te', 'tè caldo (4 tazze)', { te: 4 }, { te_foglie: 1 }, { st: 'cucina|stufa', tools: ['pentola'], min: 10, kind: 'cucina' });
  rc('bollire', 'bollire l\'acqua di cisterna', { acqua: 3 }, { acqua_pozzo: 3 }, { st: 'cucina|stufa', tools: ['pentola'], min: 30, kind: 'cucina' });
  rc('conserva', 'conserva di pomodoro (3 barattoli)', { conserva: 3 }, { pomodori: 3, barattolo: 3, sale: 1 }, { st: 'cucina|stufa', tools: ['pentola'], min: 90, kind: 'cucina' });
  rc('formaggio', 'formaggio', { formaggio: 1 }, { latte: 6, sale: 1 }, { st: 'cucina', tools: ['pentola'], min: 120, kind: 'cucina' });
  rc('pane', 'pane (8 pagnotte)', { pane: 8 }, { farina: 1, lievito: 1 }, { st: 'forno', min: 60, kind: 'cucina' });
  rc('focaccia', 'focaccia (8 pezzi)', { focaccia: 8 }, { farina: 1, olio: 1, lievito: 1 }, { st: 'forno', min: 60, kind: 'cucina' });
  rc('biscotti', 'biscotti (6 pacchi)', { biscotti: 6 }, { farina: 1, zucchero: 1, uova: 1 }, { st: 'forno', min: 60, kind: 'cucina' });
  rc('gallette', 'gallette che durano (6 pacchi)', { gallette: 6 }, { farina: 1, sale: 1 }, { st: 'forno', min: 90, kind: 'cucina' });
  rc('macella', 'macellare un capo', { carne: 12, salsiccia: 6, pelle: 1, strutto: 2 }, { capi: 1 }, { st: 'banco_macellaio', tools: ['coltello'], min: 180, kind: 'fai' });
  rc('salame', 'salami (2)', { salame: 2 }, { carne: 3, sale: 1 }, { st: 'banco_macellaio', tools: ['coltello'], min: 60, kind: 'cucina' });
  rc('passata', 'passata di pomodoro (4 bottiglie)', { passata: 4 }, { pomodori: 4, bottiglia_vuota: 4 }, { st: 'linea|cucina', tools: ['pentola'], min: 60, kind: 'cucina' });
  rc('mattoni', 'mattoni (un pallet)', { mattoni: 1 }, { sabbia: 2, ghiaia: 1, carbone: 1 }, { st: 'linea', min: 180, kind: 'fai' });
  rc('scatolame', 'tonno in scatola (10)', { scatolame: 10 }, { pesce: 3, latta: 1, olio: 1 }, { st: 'linea', min: 60, kind: 'cucina' });
  rc('vino', 'vino (4 bottiglie)', { vino: 4 }, { uva: 3, bottiglia_vuota: 4 }, { st: 'botti', min: 60, kind: 'cucina' });
  rc('olio', 'olio dal frantoio', { olio: 1 }, { olive: 3 }, { place: /oliveto|masseria/, min: 60, kind: 'cucina' });
  rc('grappa', 'grappa (2 bottiglie)', { grappa: 2 }, { vino: 3, legna: 1 }, { st: 'alambicco', min: 120, kind: 'cucina' });
  rc('alcol', 'alcol dalla grappa', { disinfettante: 2 }, { grappa: 1 }, { min: 5, kind: 'fai' });
  // ---- ovunque, con le mani ----
  rc('panino', 'panino imbottito (2)', { panino: 2 }, { pane: 1, 'salame|formaggio|scatolame|carne_scatola': 1 }, { tools: ['coltello'], min: 5, kind: 'cucina' });
  rc('razione', 'pacco viveri per la banda', { razione: 1 }, { 'pane|gallette|biscotti': 2, 'scatolame|carne_scatola|legumi|conserva': 2, acqua: 1 }, { min: 10, kind: 'fai' });
  rc('bende', 'bende (4)', { bende: 4 }, { 'stoffa|lenzuola': 1 }, { tools: ['forbici'], min: 15, kind: 'fai' });
  rc('bende_garze', 'bende dalle garze (2)', { bende: 2 }, { garze: 1, disinfettante: 1 }, { min: 10, kind: 'fai' });
  rc('disinfettante', 'disinfettante (2)', { disinfettante: 2 }, { alcol: 1 }, { min: 5, kind: 'fai' });
  rc('kit_medico', 'cassetta del pronto soccorso', { kit_medico: 1 }, { bende: 2, disinfettante: 1, 'cerotti|garze': 1, 'medicine|antibiotici': 1 }, { min: 15, kind: 'fai' });
  rc('molotov', 'molotov (4)', { molotov: 4 }, { benzina: 1, bottiglia_vuota: 4, stracci: 2 }, { min: 15, kind: 'fai' });
  rc('triboli', 'triboli (chiodi a tre punte)', { triboli: 1 }, { chiodi: 1, filo_ferro: 1 }, { tools: ['pinze'], min: 30, kind: 'fai' });
  rc('kit', 'kit di sabotaggio', { kit: 1 }, { nastro: 1, pile: 1, cavo: 1, zucchero: 1 }, { tools: ['pinze', 'cacciavite'], min: 30, kind: 'fai' });
  rc('sacco_sabbia', 'sacchetti di sabbia (2)', { sacco_sabbia: 2 }, { sacchi: 1, sabbia: 1 }, { tools: ['pala'], min: 20, kind: 'fai' });
  rc('malta', 'malta (3 secchi)', { malta: 3 }, { cemento: 1, sabbia: 2, 'acqua|tanica_acqua': 1 }, { tools: ['pala', 'secchio'], min: 30, kind: 'fai' });
  rc('legna', 'spaccare legna (4 fasci)', { legna: 4 }, { legno: 1 }, { tools: ['ascia'], min: 45, kind: 'fai' });
  rc('stencil', 'stencil di cartone', { stencil: 1 }, { 'cartone|cartoncino': 1 }, { tools: ['taglierino'], min: 20, kind: 'fai' });
  rc('passamontagna', 'passamontagna', { passamontagna: 1 }, { lana: 1 }, { tools: ['ferri_maglia'], min: 120, kind: 'fai' });
  rc('guanti_lana', 'guanti di lana (2 paia)', { guanti_lana: 2 }, { lana: 1 }, { tools: ['ferri_maglia'], min: 90, kind: 'fai' });
  rc('maglione', 'maglione di lana', { maglione: 1 }, { lana: 2 }, { tools: ['ferri_maglia'], min: 240, kind: 'fai' });
  rc('antenna_kit', 'antenna smontabile', { antenna_kit: 1 }, { tubi: 2, cavo_coax: 1, bulloni: 1 }, { tools: ['seghetto', 'chiave_inglese'], min: 60, kind: 'fai' });
  // ---- acqua e fuoco ----
  rc('acqua', 'riempire bottiglie (4)', { acqua: 4 }, { bottiglia_vuota: 4 }, { st: 'acqua', min: 5, kind: 'raccogli' });
  rc('tanica_acqua', 'riempire la tanica', { tanica_acqua: 1 }, { tanica_vuota: 1 }, { st: 'acqua', min: 5, kind: 'raccogli' });
  rc('acqua_pozzo', 'tirare su acqua dal pozzo (4)', { acqua_pozzo: 4 }, { bottiglia_vuota: 4 }, { place: /pozzo|cisterna|sorgente/, min: 10, kind: 'raccogli' });
  rc('carbone_legna', 'carbone di legna', { carbone: 1 }, { legno: 2 }, { place: /carbonaia/, min: 240, kind: 'fai' });
  // ---- banco da lavoro e falegname ----
  const LEGNO = 'banco_falegname|banco_lavoro';
  rc('assi', 'assi da un tronco (2 fasci)', { assi: 2 }, { legno: 1 }, { st: 'banco_falegname', tools: ['sega'], min: 60, kind: 'fai' });
  rc('travi', 'trave squadrata', { travi: 1 }, { legno: 1 }, { st: 'banco_falegname', tools: ['sega', 'ascia'], min: 60, kind: 'fai' });
  rc('casse', 'casse di legno (2)', { casse: 2 }, { assi: 1, chiodi: 1 }, { st: LEGNO, tools: ['sega', 'martello'], min: 40, kind: 'fai' });
  rc('sedia', 'sedie (2)', { sedia: 2 }, { assi: 1, chiodi: 1 }, { st: LEGNO, tools: ['sega', 'martello'], min: 60, kind: 'fai' });
  rc('tavolo', 'tavolo', { tavolo: 1 }, { assi: 2, chiodi: 1 }, { st: LEGNO, tools: ['sega', 'martello'], min: 90, kind: 'fai' });
  rc('branda', 'branda', { branda: 1 }, { assi: 1, 'telo|stoffa': 1, chiodi: 1 }, { st: LEGNO, tools: ['sega', 'martello'], min: 60, kind: 'fai' });
  rc('scaffale', 'scaffale', { scaffale: 1 }, { assi: 2, viti: 1 }, { st: LEGNO, tools: ['sega', 'cacciavite'], min: 60, kind: 'fai' });
  rc('mobili', 'armadio', { mobili: 1 }, { assi: 3, viti: 1, cerniere: 1 }, { st: 'banco_falegname', tools: ['sega', 'cacciavite', 'trapano'], min: 180, kind: 'fai' });
  rc('carriola', 'carriola', { carriola: 1 }, { assi: 1, ferro: 1, pneumatico: 1, bulloni: 1 }, { st: LEGNO, tools: ['sega', 'chiave_inglese'], min: 120, kind: 'fai' });
  rc('barricata', 'pannelli da barricata', { barricata: 1 }, { assi: 2, 'travi|compensato': 1, chiodi: 1 }, { st: LEGNO, tools: ['sega', 'martello'], min: 60, kind: 'fai' });
  rc('botola', 'botola mimetizzata', { botola: 1 }, { assi: 2, cerniere: 1, telo: 1 }, { st: LEGNO, tools: ['sega', 'martello'], min: 90, kind: 'fai' });
  rc('banco', 'banco da lavoro smontabile', { banco: 1 }, { assi: 2, travi: 1, viti: 1 }, { st: LEGNO, tools: ['sega', 'cacciavite', 'trapano'], min: 120, kind: 'fai' });
  rc('grimaldello', 'grimaldelli', { grimaldello: 1 }, { filo_ferro: 1 }, { st: 'banco_lavoro|forgia', tools: ['lima', 'pinze'], min: 60, kind: 'fai' });
  rc('timbro_falso', 'timbro falso dell\'Ufficio Rettifiche', { timbro_falso: 1 }, { 'sughero|cartoncino': 1, inchiostro: 1 }, { st: 'banco_lavoro|camera_oscura', tools: ['taglierino', 'lima', 'moduli'], min: 120, kind: 'fai' });
  rc('banco_radio', 'banco radio portatile', { banco_radio: 1 }, { assi: 1, cavo: 1, interruttore: 1, lampadine: 1 }, { st: 'banco_lavoro', tools: ['cacciavite', 'saldatore'], min: 90, kind: 'fai' });
  rc('alambicco', 'alambicco', { alambicco: 1 }, { tubi: 1, latta: 2, stagno: 1 }, { st: 'banco_lavoro|saldatrice', tools: ['saldatore', 'pinze'], min: 120, kind: 'fai' });
  // ---- forgia e saldatrice ----
  const FERRO = 'forgia';
  rc('chiodi', 'chiodi (6 scatole)', { chiodi: 6 }, { ferro: 1, carbone: 1 }, { st: FERRO, tools: ['martello'], min: 60, kind: 'fai' });
  rc('coltello', 'coltelli (3)', { coltello: 3 }, { ferro: 1, legno: 1, carbone: 1 }, { st: FERRO, tools: ['martello', 'lima'], min: 90, kind: 'fai' });
  rc('pala', 'pale (2)', { pala: 2 }, { ferro: 1, legno: 1, carbone: 1 }, { st: FERRO, tools: ['martello'], min: 90, kind: 'fai' });
  rc('piede', 'piedi di porco (2)', { piede: 2 }, { ferro: 1, carbone: 1 }, { st: FERRO, tools: ['martello'], min: 60, kind: 'fai' });
  rc('ascia', 'asce (2)', { ascia: 2 }, { ferro: 1, legno: 1, carbone: 1 }, { st: FERRO, tools: ['martello', 'lima'], min: 90, kind: 'fai' });
  rc('piccone', 'picconi (2)', { piccone: 2 }, { ferro: 1, legno: 1, carbone: 1 }, { st: FERRO, tools: ['martello'], min: 90, kind: 'fai' });
  rc('cerniere', 'cerniere (4 paia)', { cerniere: 4 }, { ferro: 1, carbone: 1 }, { st: FERRO, tools: ['martello'], min: 60, kind: 'fai' });
  rc('catena', 'catene (2)', { catena: 2 }, { ferro: 2, carbone: 1 }, { st: FERRO, tools: ['martello'], min: 120, kind: 'fai' });
  rc('tubo_stufa', 'tubi da stufa (2)', { tubo_stufa: 2 }, { 'latta|lamiera': 1 }, { st: 'forgia|saldatrice', tools: ['martello'], min: 60, kind: 'fai' });
  rc('stufa', 'stufa a legna', { stufa: 1 }, { lamiera: 2, tubo_stufa: 1, bulloni: 1, carbone: 1 }, { st: 'forgia|saldatrice', tools: ['martello', 'chiave_inglese'], min: 180, kind: 'fai' });
  rc('ferro_rottami', 'ferro dai rottami', { ferro: 2 }, { rottami: 3, carbone: 1 }, { st: 'forgia|saldatrice', tools: ['martello'], min: 120, kind: 'fai' });
  rc('porta_rinforzata', 'porta rinforzata', { porta_rinforzata: 1 }, { lamiera: 2, cerniere: 1, lucchetto: 1, bulloni: 1 }, { st: 'saldatrice|banco_lavoro', tools: ['trapano', 'chiave_inglese'], min: 180, kind: 'fai' });
  // ---- sartoria ----
  const CUCI = 'macchina_cucire';
  rc('vestiti', 'vestiti', { vestiti: 1 }, { stoffa: 2, bottoni: 1 }, { st: CUCI, min: 90, kind: 'fai' });
  rc('cappotto', 'cappotto', { cappotto: 1 }, { stoffa: 3, lana: 1, bottoni: 1 }, { st: CUCI, min: 180, kind: 'fai' });
  rc('coperta', 'coperta', { coperta: 1 }, { lana: 2, stoffa: 1 }, { st: CUCI, min: 90, kind: 'fai' });
  rc('lenzuola', 'lenzuola', { lenzuola: 1 }, { stoffa: 2 }, { st: CUCI, min: 45, kind: 'fai' });
  rc('sacchi_cuciti', 'sacchi (3)', { sacchi: 3 }, { stoffa: 1 }, { st: CUCI, min: 30, kind: 'fai' });
  rc('divisa', 'divisa dei Grigi', { divisa: 1 }, { stoffa_grigia: 2, bottoni: 1 }, { st: CUCI, tools: ['forbici'], min: 180, kind: 'fai' });
  // ---- stampa e falsi ----
  rc('volantini', 'volantini (un pacco)', { volantini: 1 }, { carta: 1, inchiostro: 1 }, { st: 'ciclostile', min: 30, kind: 'fai' });
  rc('poster', 'manifesti clandestini (8)', { poster: 8 }, { carta: 1, inchiostro: 1 }, { st: 'ciclostile', min: 40, kind: 'fai' });
  rc('libretto', 'libretti clandestini (6)', { libretto: 6 }, { carta: 1, inchiostro: 1, colla: 1 }, { st: 'ciclostile', min: 60, kind: 'fai' });
  rc('giornale', 'il giornale del Garante (20 copie)', { giornale: 20 }, { carta: 1, inchiostro: 1 }, { st: 'ciclostile', min: 60, kind: 'fai' });
  rc('foto_tessera', 'foto tessera (6)', { foto_tessera: 6 }, { rullino: 1 }, { st: 'camera_oscura', tools: ['fotocamera'], min: 60, kind: 'fai' });
  rc('documenti', 'lasciapassare falso', { documenti: 1 }, { carta_bollata: 1, foto_tessera: 1 }, { st: 'camera_oscura|banco_lavoro', tools: ['timbro_falso', 'penne'], min: 60, kind: 'fai' });
  // ---- radio ----
  rc('ricetrasmittente', 'ricetrasmittente', { ricetrasmittente: 1 }, { valvole: 2, transistor: 1, altoparlante: 1, cavo: 1, 'pile|batteria_auto': 1, casse: 1, stagno: 1 }, { st: 'banco_radio', tools: ['saldatore', 'cacciavite', 'pinze'], min: 180, kind: 'fai' });
  rc('disturbatore', 'disturbatore di frequenze', { disturbatore: 1 }, { valvole: 1, transistor: 2, cavo: 1, pile: 1, stagno: 1 }, { st: 'banco_radio', tools: ['saldatore', 'pinze'], min: 120, kind: 'fai' });
  rc('timer', 'timer a orologeria', { timer: 1 }, { sveglia: 1, pile: 1, cavo: 1 }, { st: 'banco_radio|banco_lavoro', tools: ['saldatore', 'pinze'], min: 40, kind: 'fai' });
  rc('radio_riparata', 'riparare una radio', { radiolina: 1 }, { radio_rotta: 1, valvole: 1, stagno: 1 }, { st: 'banco_radio', tools: ['saldatore', 'cacciavite'], min: 90, kind: 'fai' });
  // ---- smontare ----
  rc('sm_radio', 'smontare la radio rotta', { valvole: 1, altoparlante: 1, cavo: 1 }, { radio_rotta: 1 }, { tools: ['cacciavite'], min: 20, kind: 'smonta' });
  rc('sm_tv', 'smontare il televisore', { valvole: 2, transistor: 1, altoparlante: 1, cavo: 1, vetro: 1 }, { tv_rotta: 1 }, { tools: ['cacciavite', 'pinze'], min: 40, kind: 'smonta' });
  rc('sm_elettro', 'smontare l\'elettrodomestico', { rottami: 2, cavo: 1, interruttore: 1, bulloni: 1 }, { elettrodomestico: 1 }, { tools: ['cacciavite', 'chiave_inglese'], min: 40, kind: 'smonta' });
  rc('sm_mobile', 'smontare il mobile sfasciato', { assi: 1, viti: 1, cerniere: 1 }, { mobile_rotto: 1 }, { tools: ['martello'], min: 20, kind: 'smonta' });
  rc('sm_mobili', 'smontare un armadio', { assi: 2, viti: 1, cerniere: 1 }, { mobili: 1 }, { tools: ['cacciavite'], min: 30, kind: 'smonta' });
  rc('sm_casse', 'smontare le casse', { assi: 1, chiodi: 1 }, { casse: 2 }, { tools: ['piede|martello'], min: 10, kind: 'smonta' });
  rc('sm_ricambi', 'smontare i pezzi d\'auto', { rottami: 1, bulloni: 1, cavo: 1 }, { ricambi: 1 }, { tools: ['chiave_inglese'], min: 20, kind: 'smonta' });
  rc('sm_pneumatico', 'tagliare il pneumatico', { stracci: 2 }, { pneumatico: 1 }, { tools: ['taglierino'], min: 15, kind: 'smonta' });
  rc('sm_sveglia', 'smontare la sveglia', { rottami: 1 }, { sveglia: 1 }, { tools: ['cacciavite'], min: 10, kind: 'smonta' });
  rc('sm_vestiti', 'fare stracci dei vestiti', { stracci: 3 }, { vestiti: 1 }, { tools: ['forbici'], min: 10, kind: 'smonta' });
  // ---- raccogliere ed estrarre (fuori, con l'attrezzo giusto) ----
  rc('x_pesca', 'pescare', { pesce: 1, sarde: 1 }, {}, { tools: ['canna|rete_pesca'], place: /molo|pontile|caletta|spiaggia|punta|marina|lungomare|calata|faro/, min: 60, kind: 'raccogli', npcOut: { pesce: 3, sarde: 2, polpo: .2 } });
  rc('x_legna', 'tagliare un albero', { legno: 1, legna: 1 }, {}, { tools: ['ascia'], place: /pineta|sugheri|radura|macchia|collina|monte|bosco|villaggio/, min: 90, kind: 'raccogli', npcOut: { legno: 2, legna: 2, sughero: .3 } });
  rc('x_sabbia', 'spalare sabbia', { sabbia: 2 }, {}, { tools: ['pala'], place: /spiaggia|caletta|deserto/, min: 30, kind: 'raccogli' });
  rc('x_cava', 'lavorare in cava', { pietre: 1, ghiaia: 1 }, {}, { tools: ['piccone'], place: /cava|ruderi|rudere/, min: 60, kind: 'raccogli', npcOut: { pietre: 2, ghiaia: 2, sabbia: 1 } });
  rc('x_miniera', 'scavare carbone', { carbone: 1 }, {}, { tools: ['piccone'], place: /miniera|stazione/, min: 120, kind: 'raccogli', npcOut: { carbone: 2, rottami: .5 } });
  rc('x_orto', 'raccogliere nell\'orto', { verdura: 1, patate: 1, pomodori: 1 }, {}, { place: /masseria|ovile|villaggio|oliveto|vigne/, min: 60, kind: 'raccogli', npcOut: { verdura: 3, patate: 2, pomodori: 2, frutta: 1, cipolle: .5 } });
  rc('x_uva', 'vendemmiare', { uva: 1 }, {}, { place: /vigne|cantina/, min: 60, kind: 'raccogli', npcOut: { uva: 2, frutta: .5 } });
  rc('x_olive', 'raccogliere olive', { olive: 1 }, {}, { place: /oliveto/, min: 60, kind: 'raccogli', npcOut: { olive: 2, frutta: .3 } });
  rc('x_ovile', 'mungere e badare alle bestie', { latte: 2, uova: 1 }, {}, { place: /ovile/, min: 60, kind: 'raccogli', npcOut: { latte: 3, uova: 1, lana: .3, capi: .08 } });
  rc('x_sale', 'raccogliere il sale', { sale: 2 }, {}, { tools: ['pala'], place: /saline|salinaio/, min: 60, kind: 'raccogli', npcOut: { sale: 5 } });
  // quanto vale quello che non si compra in bottega: quanto costano i pezzi, più il lavoro
  for (let k = 0; k < 3; k++) Object.values(RECIPES).forEach(rec => { const outs = Object.entries(rec.out); if (outs.length !== 1) return; const [g, q] = outs[0]; if (!CAT[g] || CAT[g].prezzo > 0) return;
    const vin = Object.entries(rec.in).reduce((s, [key, n]) => s + n * Math.min(...alts(key).map(id => (CAT[id] && CAT[id].prezzo) || 1)), 0); if (!(vin > 0) && !rec.npcOut) return; CAT[g].prezzo = r1(Math.max(.5, (vin * 1.3 + rec.min / 30) / q)); });
  const NPC_ONLY = new Set();   // ricette che il giocatore vede solo dove si possono fare (le estrazioni)

  // chi produce cosa per mestiere: [titolo, postazione o luogo, ricette che sa fare]
  const JOBPROD = [
    [/^fornai/, ['pane', 'pane', 'focaccia', 'biscotti', 'gallette']],
    [/^macellai|garzone di macelleria/, ['macella', 'salame']],
    [/^pescator/, ['x_pesca']],
    [/^cuoc|^oste$|cuoco della mensa|^cuoca/, ['pasto_pasta', 'pasto_minestra', 'pasto_pesce', 'pasto_carne', 'pasto_riso']],
    [/^operai/, ['scatolame', 'passata'], /Conservificio/],
    [/^operai/, ['mattoni'], /Mattonificio|Fornace/],
    [/saldator/, ['ferro_rottami', 'tubo_stufa', 'porta_rinforzata']],
    [/carpentiere/, ['assi', 'travi', 'casse', 'barricata']],
    [/^fabbr|apprendista fabbro/, ['chiodi', 'chiodi', 'coltello', 'pala', 'piede', 'cerniere', 'ascia', 'piccone', 'tubo_stufa', 'stufa', 'catena', 'ferro_rottami']],
    [/falegnam/, ['assi', 'assi', 'travi', 'casse', 'sedia', 'tavolo', 'branda', 'scaffale', 'mobili', 'carriola']],
    [/boscaiol/, ['x_legna']],
    [/salinar/, ['x_sale']],
    [/^sart/, ['vestiti', 'cappotto', 'coperta', 'lenzuola', 'sacchi_cuciti']],
    [/^bracciante$/, ['x_orto']],
    [/bracciante delle vigne/, ['x_uva']],
    [/vignaiol/, ['vino']],
    [/bracciante dell'oliveto/, ['x_olive', 'olio']],
    [/allevator/, ['x_ovile', 'formaggio']],
    [/cavator/, ['x_cava']],
    [/minator/, ['x_miniera']],
    [/carbonai/, ['carbone_legna']],
    [/tipograf/, ['giornale']],
    [/farmacist/, ['disinfettante', 'bende_garze']],
    [/^commesso$/, ['radio_riparata']],
    [/apprendista meccanico/, ['sm_ricambi', 'sm_elettro']],
  ];

  // i mestieri che mancavano: chi scava il carbone in miniera e chi lo fa con la legna alla carbonaia
  (function newJobs() { if (I.OUTDOOR.some(o => o[1] === 'minatore')) return; if (PLACES.miniera) I.OUTDOOR.push(['miniera', 'minatore', 4, 6, 6, 14]); if (PLACES.carbonaia) I.OUTDOOR.push(['carbonaia', 'carbonaio', 2, 5, 6, 16]); I.ESSENTIAL.push(/^minator/, /^carbonai/); I.GENDER.push(['minatore', 'minatrice'], ['carbonaio', 'carbonaia']); })();

  // =====================================================================================================================
  // LE BOTTEGHE: chi vende cosa (ref come in Economia: id di un luogo o 'use:<uso>')
  // =====================================================================================================================
  const SHOPLIST = [
    ['wu', ['pane', 'pasta', 'riso', 'passata', 'scatolame', 'legumi', 'farina', 'zucchero', 'sale', 'caffe', 'te_foglie', 'latte', 'uova', 'formaggio', 'salame', 'olio', 'vino', 'birra', 'acqua', 'biscotti', 'candele', 'fiammiferi', 'sapone', 'gesso', 'carte', 'sigarette', 'aranciata']],
    ['use:emporio', ['pasta', 'riso', 'farina', 'zucchero', 'caffe', 'scatolame', 'carne_scatola', 'legumi', 'biscotti', 'cioccolato', 'gallette', 'birra', 'acqua', 'aranciata', 'coperta', 'lenzuola', 'vestiti', 'maglione', 'cappotto', 'scarpe', 'guanti_lana',
      'pentola', 'padella', 'moka', 'torcia', 'pile', 'lampadine', 'radiolina', 'sveglia', 'fornello', 'bombola', 'tanica_vuota', 'secchio', 'nastro', 'colla', 'carta', 'quaderno', 'penne', 'sapone', 'detersivo', 'candeggina', 'dentifricio', 'rasoio', 'candele', 'fiammiferi', 'accendino', 'macchina_cucire', 'cassetta', 'zaino', 'carbone', 'legna', 'stoffa', 'lana']],
    ['use:panetteria', ['pane', 'focaccia', 'biscotti', 'gallette', 'farina', 'lievito']],
    ['use:macelleria', ['carne', 'salsiccia', 'salame', 'strutto', 'pelle']],
    ['use:pescheria', ['pesce', 'sarde', 'polpo', 'scatolame', 'sale']],
    ['use:fruttivendolo', ['verdura', 'frutta', 'patate', 'pomodori', 'cipolle', 'limoni', 'olive', 'olio', 'miele']],
    ['use:ferramenta', ['chiodi', 'viti', 'bulloni', 'cerniere', 'lucchetto', 'catena', 'filo_ferro', 'corda', 'nastro', 'colla', 'sacchi', 'secchio', 'vernice', 'bomboletta', 'tanica_vuota', 'guanti',
      'martello', 'cacciavite', 'pinze', 'tronchesi', 'chiave_inglese', 'seghetto', 'sega', 'lima', 'trapano', 'taglierino', 'forbici', 'cazzuola', 'pala', 'piede', 'carriola', 'saldatore', 'stagno',
      'lampadine', 'pile', 'cavo', 'interruttore', 'torcia', 'telo', 'rete', 'tubi', 'alcol', 'candele', 'fiammiferi']],
    ['use:tabacchi', ['sigarette', 'tabacco', 'fiammiferi', 'accendino', 'carte', 'gesso', 'penne', 'quaderno', 'buste', 'carta_bollata', 'giornale', 'carta', 'cartoncino', 'inchiostro']],
    ['officina', ['olio_motore', 'batteria_auto', 'pneumatico', 'ricambi', 'tanica_vuota', 'chiave_inglese', 'piede', 'bomboletta', 'vernice', 'cavo', 'nastro', 'guanti']],
    ['benzina', ['benzina', 'gasolio', 'olio_motore', 'tanica_vuota']],
    ['video', ['radiolina', 'telefono', 'fotocamera', 'rullino', 'cassetta', 'pile', 'valvole', 'transistor', 'cavo_coax', 'altoparlante', 'saldatore', 'stagno', 'ingranditore']],
    ['use:farmacia', ['medicine', 'antibiotici', 'garze', 'bende', 'cerotti', 'disinfettante', 'siringhe', 'alcol', 'sapone', 'spugne', 'dentifricio']],
    ['use:fabbro', ['coltello', 'pala', 'piede', 'ascia', 'piccone', 'chiodi', 'cerniere', 'catena', 'tubo_stufa', 'stufa', 'ferro']],
    ['use:falegnameria', ['assi', 'travi', 'casse', 'sedia', 'tavolo', 'branda', 'scaffale', 'mobili', 'carriola', 'compensato']],
    ['use:sartoria', ['stoffa', 'lana', 'bottoni', 'ago_filo', 'ferri_maglia', 'vestiti', 'cappotto', 'coperta', 'lenzuola', 'sacchi']],
    ['use:tipografia', ['carta', 'cartoncino', 'inchiostro', 'buste', 'giornale']],
    ['use:lavanderia', ['sapone', 'detersivo', 'candeggina']],
    ['use:barbiere', ['rasoio', 'sapone', 'forbici']],
    ['osteria', ['pasto', 'vino', 'birra', 'grappa', 'caffe_tazza', 'acqua']], ['osteria_sg', ['pasto', 'vino', 'grappa', 'acqua']], ['car_2', ['pasto', 'vino', 'birra', 'acqua']],
    ['bar', ['caffe_tazza', 'pane', 'panino', 'vino', 'birra', 'grappa', 'acqua', 'aranciata', 'sigarette']], ['sirena', ['caffe_tazza', 'pane', 'panino', 'vino', 'birra', 'grappa', 'whisky', 'acqua']],
    ['disco', ['birra', 'whisky', 'aranciata', 'sigarette']], ['gelateria', ['gelato', 'latte', 'biscotti', 'pane', 'aranciata']], ['chiosco', ['pane', 'panino', 'birra', 'acqua', 'aranciata', 'gelato']],
    ['piazza', ['verdura', 'frutta', 'patate', 'pomodori', 'cipolle', 'pesce', 'sarde', 'formaggio', 'uova', 'olio', 'carne', 'salame', 'miele', 'lana', 'legna', 'vestiti']],
    ['cantiere', ['cemento', 'sabbia', 'ghiaia', 'mattoni', 'lamiera', 'tondino', 'travi', 'rete', 'filo_spinato', 'tubi', 'cazzuola', 'secchio', 'carriola', 'sacchi', 'rottami']],
    ['magazzino', ['zaino', 'benzina', 'sigarette_contr', 'whisky', 'carne_scatola', 'caffe', 'cioccolato', 'telefono', 'fotocamera', 'radiolina', 'antibiotici', 'morfina', 'munizioni', 'grimaldello', 'stoffa_grigia', 'valuta', 'merce', 'ciclostile', 'bombola', 'batteria_auto']],
    ['masseria', ['uova', 'latte', 'formaggio', 'verdura', 'patate', 'legna', 'lana']],
    ['cantina', ['vino', 'grappa']],
  ];
  // la nave porta quello che l'isola non fa (e quello che fa ma non basta)
  const IMPORT = Object.values(CAT).filter(o => o.imp).map(o => o.id).concat(['farina', 'pasta', 'scatolame', 'carbone', 'stoffa', 'ferro', 'lamiera', 'medicine', 'vestiti']).filter((v, i, a) => a.indexOf(v) === i);

  // =====================================================================================================================
  // DA FRUGARE: cosa si trova in quale mobile, a seconda della stanza e dell'edificio. [oggetto, probabilità, quanti min, max]
  // =====================================================================================================================
  const LOOT = {
    kitchenCabinet: [['pasta', .6, 1, 2], ['scatolame', .5, 1, 3], ['legumi', .3, 1, 2], ['sale', .5, 1, 1], ['zucchero', .4, 1, 1], ['caffe', .4, 1, 1], ['fiammiferi', .6, 1, 2], ['candele', .4, 1, 1], ['pentola', .3, 1, 1], ['padella', .2, 1, 1], ['moka', .3, 1, 1], ['bottiglia_vuota', .5, 1, 4], ['barattolo', .4, 1, 3], ['olio', .3, 1, 1], ['farina', .2, 1, 1], ['passata', .3, 1, 2], ['riso', .2, 1, 1], ['conserva', .2, 1, 2]],
    kitchenCabinetDrawer: [['coltello', .5, 1, 1], ['forbici', .3, 1, 1], ['fiammiferi', .5, 1, 1], ['candele', .3, 1, 2], ['pile', .3, 1, 2], ['nastro', .2, 1, 1], ['ago_filo', .3, 1, 1], ['cacciavite', .15, 1, 1], ['stracci', .4, 1, 2]],
    kitchenFridge: [['latte', .5, 1, 2], ['uova', .5, 1, 1], ['formaggio', .4, 1, 1], ['salame', .3, 1, 1], ['verdura', .4, 1, 2], ['birra', .3, 1, 3], ['acqua', .5, 1, 2], ['carne', .2, 1, 1], ['pomodori', .3, 1, 1]],
    bookcaseClosedWide: [['vestiti', .5, 1, 2], ['coperta', .4, 1, 1], ['lenzuola', .4, 1, 1], ['maglione', .3, 1, 1], ['cappotto', .15, 1, 1], ['scarpe', .2, 1, 1], ['stoffa', .15, 1, 1], ['lana', .15, 1, 1], ['medicine', .15, 1, 1], ['carte', .2, 1, 1], ['radio_rotta', .08, 1, 1]],
    sideTable: [['sigarette', .4, 1, 1], ['accendino', .3, 1, 1], ['fiammiferi', .3, 1, 1], ['orologio', .12, 1, 1], ['gioielli', .06, 1, 1], ['pile', .2, 1, 2], ['candele', .2, 1, 1], ['medicine', .2, 1, 1], ['sveglia', .3, 1, 1], ['libretto', .02, 1, 2]],
    desk: [['carta', .4, 1, 1], ['penne', .6, 1, 2], ['quaderno', .4, 1, 2], ['buste', .3, 1, 2], ['inchiostro', .2, 1, 1], ['forbici', .2, 1, 1], ['nastro', .2, 1, 1], ['carta_bollata', .15, 1, 2], ['sigarette', .2, 1, 1], ['pile', .15, 1, 1]],
    bathroomSink: [['sapone', .6, 1, 2], ['dentifricio', .5, 1, 1], ['rasoio', .4, 1, 1], ['medicine', .3, 1, 1], ['cerotti', .3, 1, 1], ['disinfettante', .2, 1, 1], ['garze', .15, 1, 1], ['alcol', .15, 1, 1]],
    washer: [['detersivo', .5, 1, 1], ['candeggina', .3, 1, 1], ['stracci', .6, 1, 3], ['sapone', .3, 1, 1]],
    cardboardBoxClosed: [['stracci', .4, 1, 3], ['bottiglia_vuota', .4, 1, 4], ['corda', .2, 1, 1], ['sacchi', .3, 1, 2], ['lampadine', .2, 1, 2], ['chiodi', .2, 1, 1], ['viti', .15, 1, 1], ['vestiti', .2, 1, 1], ['radio_rotta', .1, 1, 1], ['sveglia', .1, 1, 1], ['cartone', .5, 1, 2], ['candele', .2, 1, 2], ['scatolame', .15, 1, 2], ['latta_vuota', .3, 1, 3], ['giornale', .3, 1, 2]],
    trashcan: [['bottiglia_vuota', .5, 1, 3], ['stracci', .4, 1, 2], ['giornale', .5, 1, 2], ['latta_vuota', .5, 1, 3], ['cartone', .5, 1, 2], ['barattolo', .3, 1, 2], ['rottami', .1, 1, 1]],
    bookcaseOpen: [['quaderno', .2, 1, 1], ['giornale', .3, 1, 2], ['candele', .2, 1, 1], ['carte', .1, 1, 1], ['cartone', .2, 1, 1]],
    pv_attrezzi: [['martello', .5, 1, 1], ['chiave_inglese', .6, 1, 1], ['cacciavite', .5, 1, 1], ['pinze', .4, 1, 1], ['bulloni', .5, 1, 2], ['nastro', .5, 1, 2], ['olio_motore', .3, 1, 1], ['cavo', .3, 1, 1], ['ricambi', .3, 1, 1]],
    st_cassetta: [['martello', .4, 1, 1], ['cacciavite', .5, 1, 1], ['pinze', .4, 1, 1], ['chiave_inglese', .35, 1, 1], ['seghetto', .25, 1, 1], ['lima', .3, 1, 1], ['tronchesi', .2, 1, 1], ['nastro', .5, 1, 2], ['viti', .5, 1, 2], ['bulloni', .4, 1, 2], ['chiodi', .5, 1, 2], ['filo_ferro', .4, 1, 1], ['cavo', .25, 1, 1], ['guanti', .3, 1, 1], ['saldatore', .1, 1, 1], ['stagno', .15, 1, 1]],
    st_cassaforte: [['$', .9, 40, 260], ['gioielli', .3, 1, 2], ['orologio', .3, 1, 2], ['valuta', .2, 1, 3], ['carta_bollata', .3, 1, 4], ['moduli', .2, 1, 2], ['fascicolo', .15, 1, 1]],
    st_rastrelliera: [['munizioni', .7, 1, 3], ['pistola', .3, 1, 1], ['lupara', .15, 1, 1], ['manette', .5, 1, 2], ['divisa', .4, 1, 1], ['stoffa_grigia', .3, 1, 2], ['torcia', .5, 1, 1], ['gallette', .4, 1, 3], ['kit_medico', .2, 1, 1], ['ricetrasmittente', .08, 1, 1]],
    'ar_cash-register': [['$', 1, 0, 0]], pv_banco_vendita: [['$shop', 1, 1, 3]],
    fd_barrel: [['vino', .6, 1, 3], ['olive', .3, 1, 2], ['sarde', .3, 1, 2]],
    'fx_box-large': [['latta', .4, 1, 2], ['scatolame', .5, 2, 6], ['olio', .3, 1, 2], ['rottami', .3, 1, 2]], 'fx_box-small': [['bulloni', .4, 1, 2], ['latta_vuota', .4, 1, 4], ['nastro', .3, 1, 1]],
  };
  // stanze speciali: lo stesso mobile in un archivio della Tutela o in un'armeria non ha quello che ha in casa
  const ROOM_LOOT = {
    archivio: { bookcaseClosedWide: [['fascicolo', .35, 1, 1], ['moduli', .5, 1, 3], ['carta_bollata', .4, 1, 3], ['carta', .4, 1, 1], ['timbro_falso', .03, 1, 1], ['giornale', .3, 1, 3]] },
    ufficio: { desk: [['moduli', .3, 1, 2], ['carta_bollata', .3, 1, 3], ['carta', .4, 1, 1], ['penne', .6, 1, 2], ['inchiostro', .3, 1, 1], ['buste', .4, 1, 3], ['fascicolo', .06, 1, 1], ['$', .3, 5, 30]] },
    armeria: { bookcaseClosedWide: [['munizioni', .6, 1, 2], ['divisa', .4, 1, 1], ['manette', .4, 1, 1], ['torcia', .4, 1, 1]], cardboardBoxClosed: [['gallette', .6, 1, 4], ['munizioni', .3, 1, 2], ['stoffa_grigia', .3, 1, 2], ['bende', .4, 1, 2]] },
    camerata: { bedSingle: [['sigarette', .4, 1, 1], ['divisa', .1, 1, 1], ['gallette', .3, 1, 2], ['carte', .2, 1, 1]] },
    visite: { desk: [['medicine', .5, 1, 2], ['siringhe', .4, 1, 2], ['garze', .5, 1, 2], ['antibiotici', .2, 1, 1], ['morfina', .05, 1, 1]] },
    farmacia: { bookcaseOpen: [['medicine', .6, 1, 3], ['bende', .5, 1, 2], ['cerotti', .5, 1, 2], ['disinfettante', .4, 1, 2], ['antibiotici', .25, 1, 1]] },
    magazzino: { bookcaseOpen: [['$shop', 1, 2, 5]], cardboardBoxClosed: [['$shop', .8, 1, 4]] },
    bottega: { bookcaseOpen: [['$shop', 1, 1, 3]], bookcaseOpenLow: [['$shop', 1, 1, 3]] },
    ferramenta: { bookcaseOpen: [['$shop', 1, 1, 3]], bookcaseOpenLow: [['$shop', 1, 1, 3]], 'fx_box-small': [['$shop', 1, 1, 3]] },
    tabacchi: { bookcaseOpen: [['$shop', 1, 1, 3]] }, panetteria: { kitchenBar: [['$shop', .8, 1, 3]] }, pescheria: { kitchenBar: [['$shop', .8, 1, 2]] },
    retro: { kitchenFridge: [['$shop', .8, 1, 3]] }, sala: { kitchenBar: [['$shop', .6, 1, 2]] }, cella_frigo: { kitchenFridge: [['$shop', 1, 2, 4]] },
    caveau: { bookcaseClosedWide: [['$bank', 1, 0, 0]] },
    deposito: { cardboardBoxClosed: [['rottami', .3, 1, 2], ['corda', .3, 1, 1], ['sacchi', .3, 1, 2], ['telo', .2, 1, 1], ['tubi', .15, 1, 1], ['assi', .2, 1, 1], ['casse', .3, 1, 2], ['bombola', .1, 1, 1], ['ricambi', .2, 1, 1]] },
    soppalco: { cardboardBoxClosed: [['elettrodomestico', .2, 1, 1], ['mobile_rotto', .2, 1, 1], ['tv_rotta', .1, 1, 1], ['radio_rotta', .2, 1, 1], ['stracci', .4, 1, 2]] },
    ripostiglio: { cardboardBoxClosed: [['radio_rotta', .15, 1, 1], ['tv_rotta', .06, 1, 1], ['elettrodomestico', .08, 1, 1], ['corda', .3, 1, 1], ['secchio', .3, 1, 1], ['legna', .3, 1, 2], ['carbone', .15, 1, 1], ['lampadine', .3, 1, 2], ['pala', .1, 1, 1], ['tanica_vuota', .2, 1, 1]] },
    tipografia: { cardboardBoxClosed: [['carta', .7, 1, 3], ['inchiostro', .5, 1, 2], ['cartoncino', .5, 1, 2], ['giornale', .6, 2, 6]] },
    sartoria: { table: [['stoffa', .6, 1, 2], ['bottoni', .6, 1, 2], ['ago_filo', .6, 1, 2], ['forbici', .4, 1, 1], ['lana', .4, 1, 2]] },
  };
  // i posti all'aperto dove si fruga per terra (discarica, ruderi, cantiere, molo): si ricaricano coi giorni
  const SPOT_LOOT = {
    discarica: [['rottami', .7, 1, 3], ['radio_rotta', .3, 1, 1], ['tv_rotta', .25, 1, 1], ['elettrodomestico', .3, 1, 1], ['mobile_rotto', .3, 1, 1], ['stracci', .5, 1, 3], ['bottiglia_vuota', .6, 2, 6], ['latta_vuota', .5, 2, 5], ['pneumatico', .3, 1, 1], ['cartone', .5, 1, 3], ['ricambi', .3, 1, 1], ['barattolo', .4, 1, 3], ['tubi', .15, 1, 1], ['vetro', .1, 1, 1]],
    ruderi: [['pietre', .6, 1, 2], ['rottami', .4, 1, 2], ['assi', .2, 1, 1], ['mobile_rotto', .2, 1, 1], ['bottiglia_vuota', .3, 1, 2], ['tubi', .1, 1, 1]],
    rudere_o: [['pietre', .6, 1, 2], ['rottami', .3, 1, 1], ['assi', .2, 1, 1], ['mobile_rotto', .15, 1, 1]],
    cantiere: [['assi', .4, 1, 1], ['chiodi', .5, 1, 2], ['rottami', .4, 1, 2], ['sacchi', .3, 1, 2], ['tondino', .3, 1, 1], ['filo_ferro', .3, 1, 1], ['cemento', .15, 1, 1], ['secchio', .2, 1, 1], ['telo', .2, 1, 1]],
    molo: [['corda', .5, 1, 1], ['rete_pesca', .1, 1, 1], ['casse', .3, 1, 1], ['sarde', .3, 1, 2], ['bottiglia_vuota', .3, 1, 2], ['telo', .15, 1, 1]],
    calata: [['casse', .4, 1, 2], ['corda', .3, 1, 1], ['sacchi', .4, 1, 2], ['merce', .05, 1, 1], ['bulloni', .2, 1, 1]],
    spiaggia: [['bottiglia_vuota', .4, 1, 2], ['corda', .2, 1, 1], ['assi', .15, 1, 1], ['stracci', .3, 1, 1]],
    stazione_n: [['rottami', .5, 1, 2], ['carbone', .4, 1, 2], ['tubi', .2, 1, 1], ['cavo', .15, 1, 1]], stazione_s: [['rottami', .5, 1, 2], ['carbone', .4, 1, 2], ['tubi', .2, 1, 1], ['bulloni', .2, 1, 1]],
    miniera: [['carbone', .6, 1, 2], ['rottami', .3, 1, 1], ['piccone', .05, 1, 1], ['catena', .1, 1, 1]],
    campeggio_o: [['bottiglia_vuota', .4, 1, 2], ['telo', .2, 1, 1], ['scatolame', .2, 1, 1], ['legna', .4, 1, 1]], campeggio_e: [['bottiglia_vuota', .4, 1, 2], ['telo', .2, 1, 1], ['scatolame', .2, 1, 1], ['legna', .4, 1, 1]],
    bivacco_o: [['legna', .6, 1, 2], ['fiammiferi', .3, 1, 1], ['scatolame', .2, 1, 1]], bivacco_e: [['legna', .6, 1, 2], ['fiammiferi', .3, 1, 1], ['scatolame', .2, 1, 1]],
  };

  // =====================================================================================================================
  // COSTRUIRE (Risacca): le strutture e i moduli si pagano in oggetti
  // =====================================================================================================================
  const BUILD = {
    struct: {
      baracca: { assi: 4, lamiera: 2, chiodi: 2, travi: 1 },
      capanno: { assi: 6, lamiera: 4, travi: 2, chiodi: 3, cerniere: 1, lucchetto: 1 },
      rifugio: { travi: 4, assi: 6, cemento: 3, sabbia: 4, sacco_sabbia: 6, botola: 1, chiodi: 2 },
      antenna: { antenna_kit: 1, cavo_coax: 1, tubi: 1, bulloni: 1 },
    },
    module: {
      deposito: { scaffale: 2, casse: 2 },
      dormitorio: { 'branda|materasso': 3, coperta: 3 },
      stamperia: { ciclostile: 1, tavolo: 1 },
      radio: { ricetrasmittente: 1, 'batteria_auto|pile': 1, cavo_coax: 1 },
      falsari: { ingranditore: 1, tavolo: 1, lampadine: 1 },
      officina: { banco: 1, martello: 1, cacciavite: 1, pinze: 1 },
      infermeria: { branda: 1, kit_medico: 1, tavolo: 1 },
      armeria: { scaffale: 1, catena: 1, lucchetto: 1, 'porta_rinforzata': 1 },
    },
    // quello che le altre azioni chiedevano in «materiali» astratti
    inchioda: { assi: 2, chiodi: 1 },
  };
  // le postazioni che un modulo mette in base (oltre a quelle degli oggetti posati lì)
  const MOD_ST = { stamperia: ['ciclostile'], falsari: ['camera_oscura', 'banco_lavoro'], officina: ['banco_lavoro', 'banco_falegname'], infermeria: ['tavolo_medico'], radio: ['banco_radio'] };

  // =====================================================================================================================
  // LO STATO
  // =====================================================================================================================
  function S(st) {
    if (st.ogg) return st.ogg;
    st.ogg = { cont: {}, spots: {}, wear: {}, hour: -1, primed: false, stats: { prodotto: 0, ricette: 0, consumi: 0, frugato: 0, rubato: 0, scoperto: 0, fatto: 0, rotti: 0 }, made: {}, log: [] };
    return st.ogg;
  }
  const inv = st => { const p = st.player; p.inv = p.inv || {}; return p.inv; };
  const cnt = (bag, id) => Math.floor((bag && bag[id]) || 0);
  function add(bag, id, q) { if (!(q > 0)) return; bag[id] = r1((bag[id] || 0) + q); }
  function sub(bag, id, q) { bag[id] = r1((bag[id] || 0) - q); if (bag[id] <= 0) delete bag[id]; }
  // quanto si porta addosso
  function weightOf(bag) { return Object.entries(bag || {}).reduce((s, [k, v]) => s + (CAT[k] ? CAT[k].peso * v : .5 * v), 0); }
  function capacity(st) { const b = inv(st); let c = 30; if (cnt(b, 'zaino')) c += CAT.zaino.bag; if (st.player.hand === 'carriola') c += 100; return c; }
  // le armi del motore: chi compra o trova una pistola la ha tra le armi, non in tasca
  function giveWeapon(st, id, q) {
    const p = st.player, w = CAT[id] && CAT[id].wpn; if (!w || !G.WEAPONS[w]) return false;
    if (w === 'molotov') { p.arms.molotov = p.arms.molotov || { mag: 0, res: 0 }; p.arms.molotov.mag = (p.arms.molotov.mag || 0) + q; return true; }
    if (p.arms[w]) { if (!G.WEAPONS[w].melee) p.arms[w].res = (p.arms[w].res || 0) + G.WEAPONS[w].mag * q; return true; }
    p.arms[w] = G.WEAPONS[w].melee ? {} : { mag: G.WEAPONS[w].mag, res: G.WEAPONS[w].mag * 2 }; return true;
  }
  function giveAmmo(st, q) { const p = st.player; const g = ['pistola', 'mitra', 'lupara'].find(w => p.arms[w]); if (!g) return false; p.arms[g].res = (p.arms[g].res || 0) + 15 * q; return true; }
  // al giocatore: in tasca (o tra le armi). Restituisce quanto non ci stava
  function givePlayer(st, id, q, force) {
    if (!(q > 0)) return 0;
    if (CAT[id] && CAT[id].wpn && G.WEAPONS[CAT[id].wpn]) { if (id === 'coltello') { add(inv(st), id, q); return 0; } giveWeapon(st, id, q); return 0; }
    if (id === 'munizioni' && giveAmmo(st, q)) return 0;
    const b = inv(st), w = CAT[id] ? CAT[id].peso : .5, room = capacity(st) - weightOf(b);
    let k = force ? q : Math.min(q, Math.max(0, Math.floor(room / Math.max(.01, w) + 1e-6)));
    add(b, id, k); return q - k;
  }

  // =====================================================================================================================
  // DOVE SONO (postazioni, contenitori, luoghi)
  // =====================================================================================================================
  const p_ = st => st.player;
  function nearPlace(st, r) { const p = p_(st); let best = null, bd = r || 14; Object.entries(PLACES).forEach(([id, P0]) => { const d = dist(P0.x, P0.y, p.x, p.y); if (d < bd) { bd = d; best = id; } }); return best; }
  function nearBase(st) { const R = st.ris; if (!R) return null; const p = p_(st); return R.bases.find(b => b.alive && dist(b.x, b.y, p.x, p.y) < 6) || null; }
  // i mobili vicini (dentro un edificio)
  function nearFurn(st, r) {
    const p = p_(st); if (!p.indoor) return [];
    const b = G.BUILDINGS[p.indoor.b], Lx = INT.layout(b), F = Lx.floors[p.indoor.f]; if (!F) return [];
    return F.furn.map((o, i) => ({ o, i, d: dist(o.x, o.y, p.x, p.y), room: (INT.roomAt ? (INT.roomAt(Lx, p.indoor.f, o.x, o.y) || {}).name : null) })).filter(x => x.d < (r || 2.4)).sort((a, c) => a.d - c.d);
  }
  // le postazioni a portata: mobili dell'interno, moduli e oggetti della base, la fontana, il fornello che hai nello zaino
  function stationsHere(st) {
    const out = new Set(), p = p_(st);
    nearFurn(st, 2.6).forEach(x => { const s = FURN2ST[x.o.id]; if (s) out.add(s); });
    const b = nearBase(st);
    if (b) { (b.modules || []).forEach(m => (MOD_ST[m] || []).forEach(s => out.add(s))); Object.keys(b.stock || {}).forEach(k => { if (CAT[k] && CAT[k].st) out.add(CAT[k].st); }); }
    Object.keys(inv(st)).forEach(k => { const c = CAT[k]; if (c && c.st && c.peso <= 4) out.add(c.st); });
    if (!p.indoor) { const pl = nearPlace(st, 10); if (pl && /fontana|sorgente/.test(pl)) out.add('acqua'); if (nearTile(st, G.T.FOUNT, 3)) out.add('acqua'); }
    return out;
  }
  function nearTile(st, t, r) { if (t === undefined) return false; const p = p_(st), tx = Math.floor(p.x / TS), ty = Math.floor(p.y / TS); for (let j = -r; j <= r; j++) for (let i = -r; i <= r; i++) if (G.tileAt && G.tileAt(tx + i, ty + j) === t) return true; return false; }
  // tutto quello che il giocatore può usare qui: le tasche, e se è in base anche le scorte della base
  function pools(st) { const L0 = [inv(st)]; const b = nearBase(st); if (b) L0.push(b.stock); return L0; }
  const poolCnt = (P, id) => P.reduce((s, b) => s + cnt(b, id), 0);
  function poolTake(P, id, q) { for (const b of P) { const k = Math.min(q, cnt(b, id)); if (k > 0) { sub(b, id, k); q -= k; } if (!q) break; } return q; }
  // basta quello che c'è? per ogni ingrediente sceglie l'alternativa che c'è
  function plan(P, rec, times) {
    const use = {}, miss = [];
    for (const [key, q0] of Object.entries(rec.in)) {
      const q = q0 * (times || 1), opts = alts(key), have = opts.find(id => poolCnt(P, id) - (use[id] || 0) >= q);
      if (have) use[have] = (use[have] || 0) + q; else miss.push(opts.map(nm).join(' o ') + (q > 1 ? ` ×${q}` : ''));
    }
    const tools = [];
    for (const key of rec.tools) { const opts = alts(key), have = opts.find(id => poolCnt(P, id) > 0 || (id === 'coltello' && st0 && st0.player.arms && st0.player.arms.coltello)); if (have) tools.push(have); else miss.push(`attrezzo: ${opts.map(nm).join(' o ')}`); }
    return { use, tools, miss };
  }
  let st0 = null;   // lo stato corrente per i controlli sugli attrezzi (arma bianca impugnata)
  function placeOk(st, rec) { if (!rec.place) return true; const pl = nearPlace(st, 16); return !!(pl && (rec.place.test(pl) || rec.place.test(norm(PLACES[pl].name)))); }
  function stOk(stations, rec) { if (!rec.st) return true; return alts(rec.st).some(s => stations.has(s)); }

  // =====================================================================================================================
  // FABBRICARE (il giocatore)
  // =====================================================================================================================
  function recipesView(st) {
    st0 = st; const stations = stationsHere(st), P = pools(st), out = [];
    Object.values(RECIPES).forEach(rec => {
      const here = stOk(stations, rec) && placeOk(st, rec);
      if (rec.place && !here) return;                       // le estrazioni si vedono solo dove si fanno
      const pl = plan(P, rec);
      out.push({ id: rec.id, nome: rec.nome, kind: rec.kind, min: rec.min, st: rec.st ? alts(rec.st).map(s => STATIONS[s] ? STATIONS[s].nome : s).join(' o ') : 'ovunque', here, ok: here && !pl.miss.length, miss: pl.miss,
        in: Object.entries(rec.in).map(([k, q]) => ({ k, nome: alts(k).map(nm).join(' o '), q, have: Math.max(...alts(k).map(id => poolCnt(P, id))) })),
        tools: rec.tools.map(k => ({ k, nome: alts(k).map(nm).join(' o '), have: alts(k).some(id => poolCnt(P, id) > 0) })),
        out: Object.entries(rec.out).map(([k, q]) => ({ k, nome: nm(k), q })) });
    });
    return { stations: [...stations].map(s => STATIONS[s] ? STATIONS[s].nome : s), base: nearBase(st) ? nearBase(st).name : null, list: out.sort((a, b) => (b.ok - a.ok) || (b.here - a.here) || a.nome.localeCompare(b.nome)) };
  }
  function wearTools(st, P, tools, mins) {
    const W = S(st).wear, broke = [];
    tools.forEach(id => {
      const c = CAT[id]; if (!c || !c.tool) return;
      if (W[id] === undefined || W[id] <= 0) W[id] = c.tool;
      W[id] -= Math.max(1, mins / 30);
      if (W[id] <= 0) { poolTake(P, id, 1); W[id] = c.tool; broke.push(c.nome); S(st).stats.rotti++; }
    });
    return broke;
  }
  function craft(st, id, times) {
    st0 = st; const rec = RECIPES[id]; if (!rec) return R_(false, 'Non sai come si fa.');
    const stations = stationsHere(st);
    if (!stOk(stations, rec)) return R_(false, `Serve: ${alts(rec.st).map(s => STATIONS[s].nome).join(' o ')}.`);
    if (!placeOk(st, rec)) return R_(false, 'Non qui.');
    times = Math.max(1, Math.min(10, Math.floor(times || 1)));
    const P = pools(st); let pl = plan(P, rec, times);
    while (pl.miss.length && times > 1) { times--; pl = plan(P, rec, times); }
    if (pl.miss.length) return R_(false, `Manca: ${pl.miss.join(', ')}.`);
    Object.entries(pl.use).forEach(([k, q]) => { poolTake(P, k, q); const e = CAT[k] && CAT[k].empty; if (e && rec.kind !== 'smonta' && !/^acqua$|tanica_acqua/.test(id)) add(P[0], e, 0); });
    const mins = rec.min * times, broke = wearTools(st, P, pl.tools, mins);
    const got = []; let left = 0;
    const B0 = nearBase(st), over = weightOf(inv(st)) > capacity(st);
    Object.entries(rec.out).forEach(([k, q]) => { const n = q * times; if (B0 && over) add(B0.stock, k, n); else left += givePlayer(st, k, n, true) * 0; got.push(`${nm(k)}${n > 1 ? ' ×' + n : ''}`); });
    left = weightOf(inv(st)) > capacity(st) ? 1 : 0;
    passTime(st, mins);
    const M = S(st); M.stats.fatto += times; M.made[id] = (M.made[id] || 0) + times;
    if (CAT[Object.keys(rec.out)[0]] && CAT[Object.keys(rec.out)[0]].ill) suspicious(st, rec.st && /ciclostile|alambicco/.test(rec.st) ? .35 : .15, rec.nome);
    return R_(true, `${cap(rec.nome)}: ${got.join(', ')}. ${mins >= 60 ? `${Math.round(mins / 6) / 10} ore di lavoro.` : `${mins} minuti.`}${broke.length ? ` Si è rotto: ${broke.join(', ')}.` : ''}${left > 0 ? ' Sei carico come un mulo: cammini piano finché non posi qualcosa.' : ''}`);
  }
  // il tempo passa davvero (come quando si dorme o si lavora): il mondo va avanti
  function passTime(st, mins) {
    if (!(mins > 0)) return;
    if (typeof window === 'undefined' || !G.step) { st.t += mins; return; }
    const end = st.t + mins; let guard = 0; while (st.t < end && guard++ < 4000) G.step(st, 1 / 30, {});
  }
  // chi sente il ciclostile o sente odore di grappa: un vicino può fare una soffiata
  function suspicious(st, k, what) {
    if (rnd() > k) return; const p = p_(st);
    const ear = st.npcs.find(n => !n.dead && n.pop && dist(n.x, n.y, p.x, p.y) < 18 && n.ris && n.ris.ideo < .3);
    if (!ear) return; I.note(st, ear, `ha sentito strani rumori vicino a ${G.nearestPlace(p.x, p.y).name}: ${what}`, 'shady', { w: .5, who: 'player' });
    if (st.ris) st.ris.repr = clamp(st.ris.repr + 1, 0, 100);
  }

  // =====================================================================================================================
  // USARE: mangiare, bere, medicarsi, vestirsi
  // =====================================================================================================================
  function consume(st, id) {
    const c = CAT[id], b = inv(st); if (!c || !c.eat) return R_(false, 'Non si usa così.'); if (!cnt(b, id)) return R_(false, 'Non ce l\'hai.');
    const me = st.me, N = me && me.need, E = c.eat, p = p_(st), msg = [];
    if (c.uses) { const W = S(st).wear, key = 'u:' + id; if (W[key] === undefined) W[key] = c.uses; W[key]--; if (W[key] <= 0) { sub(b, id, 1); delete W[key]; if (c.empty) add(b, c.empty, 1); } }
    else { sub(b, id, 1); if (c.empty) add(b, c.empty, 1); }
    if (N) {
      if (E.fame) N.fame = clamp(N.fame - E.fame, 0, 1); if (E.igiene) N.igiene = clamp(N.igiene + E.igiene, 0, 1); if (E.sonno) N.sonno = clamp(N.sonno + E.sonno, 0, 1);
      if (E.sete) { N.sete = clamp((N.sete || 0) + E.sete, 0, 1); }
      if (E.alcol) { me.drunk = clamp((me.drunk || 0) + E.alcol * .6, 0, 1); me.alcol = (me.alcol || 0) + E.alcol; }
    }
    if (E.calore) S(st).calore = clamp((S(st).calore || 0) + E.calore, 0, 1);
    if (E.hp) p.hp = Math.min(100, p.hp + E.hp);
    S(st).stats.consumi++;
    const verb = c.cat === 'bevande' ? 'Bevi' : c.cat === 'medicina' ? 'Ti medichi con' : c.cat === 'igiene' ? 'Usi' : 'Mangi';
    if (E.hp) msg.push(`+${E.hp} salute`); if (E.fame) msg.push('fame giù'); if (E.sete) msg.push('sete giù'); if (E.calore) msg.push('ti scaldi');
    return R_(true, `${verb} ${c.nome}${msg.length ? ' (' + msg.join(', ') + ')' : ''}.`);
  }
  // la sete: cresce come la fame, d'inverno un po' meno
  function thirstTick(st, h) { const N = st.me && st.me.need; if (!N) return; N.sete = clamp((N.sete || .2) + .045 * h, 0, 1); if (N.sete >= 1) st.player.hp = Math.max(1, st.player.hp - 2 * h); }

  // =====================================================================================================================
  // FRUGARE
  // =====================================================================================================================
  const LOCKED = { st_cassaforte: 'trapano', st_rastrelliera: 'grimaldello|piede', 'ar_cash-register': 'grimaldello|piede' };
  function lootTable(b, room, fid) { const R0 = ROOM_LOOT[room]; if (R0 && R0[fid]) return R0[fid]; if (/^bed/.test(fid)) return [['$mat', .7, 0, 0], ['coperta', .3, 1, 1], ['lenzuola', .3, 1, 1], ['libretto', .02, 1, 1]]; return LOOT[fid] || null; }
  function roll(table, rich) {
    const out = {};
    table.forEach(([id, pr, a, b]) => { if (id[0] === '$') { if (rnd() < pr) out[id] = id === '$' ? Math.round(a + rnd() * (b - a)) : (a || 1); return; } if (rnd() < pr * rich) out[id] = (out[id] || 0) + a + Math.floor(rnd() * (b - a + 1)); });
    return out;
  }
  function richness(b) { const W = typeof World !== 'undefined' ? World : null; const d = W && W.districtAt ? W.districtAt((b.x + b.w / 2) * TS) : ''; return /centro/.test(d) ? 1.25 : /perif/.test(d) ? .85 : 1; }
  function shopOfB(st, bi) { const E = Ec.eco(st); return Object.values(E.shops).find(Sh => Sh.t && Sh.t.k === 'b' && Sh.t.bi === bi) || null; }
  function container(st, x) {
    const M = S(st), p = p_(st), bi = p.indoor.b, b = G.BUILDINGS[bi], key = `b${bi}:${p.indoor.f}:${x.i}`;
    let C = M.cont[key];
    const table = lootTable(b, x.room, x.o.id); if (!table) return null;
    if (!C || (st.t - C.at > 3 * 1440 && !C.shop)) {
      const old = C; C = M.cont[key] = { key, at: st.t, items: roll(table, richness(b)), locked: !!LOCKED[x.o.id] && !(old && old.forced), forced: old ? old.forced : false, fid: x.o.id, room: x.room, bi };
      if (old && old.items) Object.entries(old.items).forEach(([k, v]) => { if (k[0] !== '$') C.items[k] = Math.min(6, (C.items[k] || 0) + v); });
    }
    C.label = furnName(x.o.id, x.room);
    return C;
  }
  const FNAME = { kitchenCabinet: 'credenza', kitchenCabinetDrawer: 'cassetti della cucina', kitchenFridge: 'frigorifero', bookcaseClosedWide: 'armadio', sideTable: 'comodino', desk: 'scrivania', bathroomSink: 'mobiletto del bagno', washer: 'lavatrice',
    cardboardBoxClosed: 'scatoloni', trashcan: 'secchio della spazzatura', bookcaseOpen: 'scaffale', bookcaseOpenLow: 'scaffale basso', st_cassetta: 'cassetta degli attrezzi', pv_attrezzi: 'parete degli attrezzi', pv_banco_vendita: 'banco di vendita', pv_banco_lavoro: 'banco da lavoro', pv_pneumatici: 'pila di pneumatici', st_cassaforte: 'cassaforte', st_rastrelliera: 'rastrelliera', 'ar_cash-register': 'registratore di cassa',
    fd_barrel: 'botte', 'fx_box-large': 'casse', 'fx_box-small': 'cassette', bedDouble: 'letto', bedSingle: 'branda', kitchenBar: 'bancone', table: 'tavolo' };
  const furnName = (id, room) => `${FNAME[id] || id}${room ? ` (${room.replace(/_r$/, '').replace(/_/g, ' ')})` : ''}`;
  // cosa contiene davvero (le voci speciali diventano roba vera: le scorte della bottega, i soldi della cassa o del materasso)
  function contView(st, C) {
    const out = [];
    Object.entries(C.items).forEach(([k, v]) => {
      if (k === '$shop') { const Sh = shopOfB(st, C.bi); if (!Sh) return; Object.keys(Sh.sells).filter(g => (Sh.stock[g] || 0) >= 1 && CAT[g]).slice(0, 8).forEach(g => out.push({ id: g, nome: nm(g), q: Math.floor(Math.min(Sh.stock[g], 3 + v)), src: 'shop', peso: CAT[g].peso })); return; }
      if (k === '$') { if (C.fid === 'ar_cash-register') { const Sh = shopOfB(st, C.bi), T = Sh && So ? So.till(st, So.ditta(st, Sh.t)) : null; const x = T ? Math.floor(Math.max(0, T.cash || 0)) : 0; if (x > 0) out.push({ id: '$', nome: `contanti (${L(x)})`, q: x, src: 'till' }); return; } if (v > 0) out.push({ id: '$', nome: `contanti (${L(v)})`, q: v, src: 'cash' }); return; }
      if (k === '$mat') { const x = Math.floor(residents(st, C.bi).reduce((s, n) => s + (n.pop.mat || 0), 0) * .8); if (x > 0) out.push({ id: '$', nome: `soldi sotto il materasso (${L(x)})`, q: x, src: 'mat' }); return; }
      if (k === '$bank') { if (!So || !st.soldi) return; const x = Math.floor(Math.min(st.soldi.banca.vault * .25, 900)); if (x > 0) out.push({ id: '$', nome: `mazzette del caveau (${L(x)})`, q: x, src: 'bank' }); return; }
      if (v >= 1) out.push({ id: k, nome: nm(k), q: Math.floor(v), src: 'c', peso: CAT[k] ? CAT[k].peso : .5 });
    });
    return out;
  }
  // chi c'è in quell'edificio adesso (chi ci abita e dorme o sta a casa, chi ci lavora ed è di turno)
  function residents(st, bi) { return st.npcs.filter(n => !n.dead && n.pop && n.pop.homeT && n.pop.homeT.k === 'b' && n.pop.homeT.bi === bi); }
  function occupants(st, bi) {
    return st.npcs.filter(n => {
      if (n.dead || !n.pop || n.jailedUntil > st.t) return false; const c = n.pop.cur; if (!c || !c.tgt || c.tgt.k !== 'b' || c.tgt.bi !== bi) return false;
      return dist(n.x, n.y, c.tgt.x, c.tgt.y) < 12;
    });
  }
  // aprire (forzare) e prendere. noise: quanto si sente; chi è in casa o in bottega se ne accorge
  function caught(st, bi, noise, what) {
    const occ = occupants(st, bi); if (!occ.length) return null;
    const M0 = S(st); M0.alarm = M0.alarm || {}; if (M0.alarm[bi] && st.t - M0.alarm[bi].t < 30) return null;   // ti hanno già visto: non serve ripeterlo
    const awake = occ.filter(n => !(n.pop.cur && n.pop.cur.act === 'sonno'));
    let who = awake.length ? (rnd() < .55 + noise ? awake[0] : null) : occ.find(() => rnd() < noise * .5);
    if (!who) return null;
    const b = G.BUILDINGS[bi], ev = G.emit(st, 'furto', { target: who.id, shop: b.name || 'una casa' });
    occ.forEach(n => { G.addMemory(st, n, { eventId: ev.id, type: 'furto', actor: 'player', target: who.id, place: b.name || 'casa', t: st.t, conf: .9, source: 'visto' }); I.note(st, n, `ha sorpreso ${G.PLAYER_NAME} a rubare ${what} in ${b.name || 'casa'}`, 'bad', { w: .8, who: 'player', tag: 'furto' }); });
    S(st).stats.scoperto++; M0.alarm[bi] = { t: st.t, who: who.id };
    G.say(st, who, pick(['«Al ladro! Al ladro!»', '«Ehi! Che fai lì?»', '«Fuori da casa mia!»', '«Chiamo la Guardia!»']), 3);
    if (G.panicAround) try { G.panicAround(st, who.x, who.y, 8); } catch (e) { }
    if (who.pop.cur.act === 'sonno') who.pop.cur.act = 'casa';
    return who;
  }
  function openC(st, C) {
    if (!C.locked) return R_(true, '');
    const need = LOCKED[C.fid], P = pools(st); st0 = st; const pl = plan(P, { in: {}, tools: [need] });
    if (pl.miss.length) return R_(false, `È chiuso a chiave. Serve: ${alts(need).map(nm).join(' o ')}.`);
    const tool = pl.tools[0], mins = tool === 'trapano' ? 45 : tool === 'grimaldello' ? 15 : 5, noise = tool === 'piede' ? .5 : tool === 'trapano' ? .35 : .08;
    const broke = wearTools(st, P, [tool], mins * 3); passTime(st, mins);
    C.locked = false; C.forced = true;
    const who = caught(st, C.bi, noise, 'forzando ' + C.label);
    return R_(true, `${tool === 'grimaldello' ? 'Click. Aperto coi grimaldelli' : tool === 'trapano' ? 'Tre quarti d\'ora di trapano: la serratura cede' : 'Uno strappo col piede di porco: aperto'}.${broke.length ? ` Si è rotto: ${broke.join(', ')}.` : ''}${who ? ` ${who.first} ti ha sentito!` : ''}`, { who: who ? who.id : null });
  }
  function takeFrom(st, C, id, q) {
    const view = contView(st, C), it = view.find(v => v.id === id); if (!it) return R_(false, 'Non c\'è più.');
    q = Math.max(1, Math.min(q || it.q, it.q)); const p = p_(st), b = G.BUILDINGS[C.bi], M = S(st);
    if (id === '$') {
      if (it.src === 'till') { const Sh = shopOfB(st, C.bi), T = So.till(st, So.ditta(st, Sh.t)); T.cash -= q; }
      else if (it.src === 'mat') { let left = q; residents(st, C.bi).forEach(n => { const k = Math.min(left, n.pop.mat || 0); n.pop.mat -= k; left -= k; if (k > 0) I.note(st, n, 'i soldi sotto il materasso sono spariti', 'bad', { w: .9, tag: 'furto' }); }); q -= left; }
      else if (it.src === 'bank') { st.soldi.banca.vault -= q; st.soldi.banca.equity -= q; }
      else { delete C.items.$; if (So && st.soldi) st.soldi.fuori -= q; /* soldi che nessuno sapeva di avere: escono dal nulla dei conti */ }
      p.money += q; M.stats.rubato += q;
      const who = caught(st, C.bi, .1, 'soldi'); return R_(true, `Intaschi ${L(q)}.${who ? ` ${who.first} ti ha visto!` : ''}`);
    }
    const left = givePlayer(st, id, q), got = q - left; if (!got) return R_(false, 'Non ti sta più niente addosso.');
    if (it.src === 'shop') { const Sh = shopOfB(st, C.bi); Sh.stock[id] -= got; M.stats.rubato += got * CAT[id].prezzo; }
    else { C.items[id] -= got; if (C.items[id] <= 0) delete C.items[id]; }
    M.stats.frugato += got;
    const home = residents(st, C.bi).length && !(st.me && st.me.home && st.me.home.bi === C.bi);
    const who = (it.src === 'shop' || home) ? caught(st, C.bi, .06, nm(id)) : null;
    return R_(true, `Prendi ${nm(id)}${got > 1 ? ' ×' + got : ''}.${left ? ' Il resto non ti sta addosso.' : ''}${who ? ` ${who.first} ti ha visto!` : ''}`);
  }
  // i posti all'aperto (discarica, ruderi, cantiere…)
  function spot(st, id) {
    const M = S(st); let C = M.spots[id];
    if (!C || st.t - C.at > 2 * 1440) { const old = C; C = M.spots[id] = { key: 'p:' + id, at: st.t, items: roll(SPOT_LOOT[id], 1), spot: id, label: PLACES[id] ? PLACES[id].name : id }; if (old) Object.entries(old.items).forEach(([k, v]) => { C.items[k] = Math.min(8, (C.items[k] || 0) + v); }); }
    return C;
  }
  function containersHere(st) {
    const p = p_(st), out = [];
    if (p.indoor) nearFurn(st, 2.2).forEach(x => { if (lootTable(G.BUILDINGS[p.indoor.b], x.room, x.o.id)) out.push({ ref: `f:${x.i}`, label: furnName(x.o.id, x.room), locked: !!LOCKED[x.o.id] && !((S(st).cont[`b${p.indoor.b}:${p.indoor.f}:${x.i}`] || {}).forced) }); });
    else { const pl = nearPlace(st, 12); if (pl && SPOT_LOOT[pl]) out.push({ ref: `p:${pl}`, label: `Fruga: ${PLACES[pl].name}` }); }
    return out;
  }
  function contByRef(st, ref) {
    if (ref.startsWith('p:')) { const id = ref.slice(2); return SPOT_LOOT[id] ? spot(st, id) : null; }
    const p = p_(st); if (!p.indoor) return null; const i = +ref.slice(2); const x = nearFurn(st, 3.2).find(y => y.i === i); return x ? container(st, x) : null;
  }
  // posare: lasciare roba in un contenitore (nascondere refurtiva, rifornire una base) — nella base va nelle scorte
  function putInto(st, C, id, q) { const b = inv(st); q = Math.min(q || 1, cnt(b, id)); if (!q) return R_(false, 'Non ce l\'hai.'); sub(b, id, q); add(C.items, id, q); return R_(true, `Lasci ${nm(id)}${q > 1 ? ' ×' + q : ''} in ${C.label}.`); }

  // =====================================================================================================================
  // COMPRARE, VENDERE, SCAMBIARE
  // =====================================================================================================================
  const price = (st, Sh, g) => Ec.price(st, Sh, g);
  const sellPrice = (st, Sh, g) => r1(CAT[g].prezzo * (Sh.black ? (CAT[g].ill ? .6 : .4) : .5) * clamp(1.4 - (Sh.stock[g] || 0) / Math.max(1, CAT[g].q || 5) * .5, .4, 1.2));
  function counter(st, k) {
    const E = Ec.eco(st), Sh = E.shops[k]; if (!Sh) return null; const b = inv(st);
    const goods = Object.keys(Sh.sells).filter(g => CAT[g]).map(g => { const c = CAT[g]; return { g, name: c.nome, cat: c.cat, catLabel: GROUPS[c.cat], price: price(st, Sh, g), base: c.prezzo, stock: Math.floor(Sh.stock[g] || 0), peso: c.peso, eat: !!c.eat, ill: !!c.ill, mine: cnt(b, g) }; });
    // cosa compra la bottega da te: quello che vende lei (il mercato nero: anche la roba che scotta)
    const buys = Object.keys(b).filter(g => CAT[g] && cnt(b, g) > 0 && (Sh.sells[g] || (Sh.black && (CAT[g].ill || CAT[g].prezzo >= 6)))).map(g => ({ g, name: nm(g), q: cnt(b, g), price: sellPrice(st, Sh, g) }));
    return { k, label: Sh.label, emporio: !!Sh.emporio, black: !!Sh.black, market: !!Sh.market, cash: Math.floor(tillOf(st, Sh)), goods, buys, wallet: st.player.money, peso: r1(weightOf(b)), cap: capacity(st) };
  }
  function tillOf(st, Sh) { if (So && st.soldi) { const T = So.till(st, So.ditta(st, Sh.t)); return T ? (T.cash || 0) : (Sh.cash || 0); } return Sh.cash || 0; }
  function tillMove(st, Sh, x) { if (So && st.soldi) { const D = So.ditta(st, Sh.t), T = So.till(st, D); if (T) { T.cash = (T.cash || 0) + x; if (x > 0) D.rev = (D.rev || 0) + x; return; } } Sh.cash = (Sh.cash || 0) + x; }
  function buy(st, k, g, q, mode) {
    const E = Ec.eco(st), Sh = E.shops[k], p = p_(st); if (!Sh) return R_(false, 'Qui non vendono niente.');
    if (!Sh.sells[g] || !CAT[g]) return R_(false, 'Non ce l\'hanno.');
    if (Sh.market && ![2, 5].includes(Po.weekday(st.t))) return R_(false, 'Oggi non c\'è mercato.');
    q = Math.max(1, Math.floor(q || 1)); if ((Sh.stock[g] || 0) < q) return R_(false, `${cap(nm(g))}: ${Sh.stock[g] >= 1 ? `ne hanno solo ${Math.floor(Sh.stock[g])}` : 'finito'}.`);
    const pr = r1(price(st, Sh, g) * q); if (p.money < pr - 1e-6) return R_(false, `Costa ${L(pr)}: non ce li hai.`);
    const c = CAT[g];
    if (mode !== 'consuma' && !c.wpn && g !== 'munizioni' && weightOf(inv(st)) + c.peso * q > capacity(st) + .01 && !nearBase(st)) return R_(false, `Pesa troppo: porti già ${r1(weightOf(inv(st)))} kg su ${capacity(st)}.`);
    Sh.stock[g] -= q; p.money -= pr; tillMove(st, Sh, pr); Ec.eco(st).stats.venduto += q;
    if (So && st.soldi) { const M = st.soldi; M.player.mov.unshift([st.t, -pr, `${c.nome} (${Sh.label})`]); M.player.mov = M.player.mov.slice(0, 40); }
    st.sfx && st.sfx.push({ k: 'cash' });
    if (Sh.emporio && st.ris) st.ris.morale = clamp(st.ris.morale - .1, 0, 100);
    if (mode === 'consuma' && c.eat) { add(inv(st), g, q); let m = ''; for (let i = 0; i < q; i++) m = consume(st, g).msg; return R_(true, `${cap(c.nome)}${q > 1 ? ' ×' + q : ''}: ${L(pr)}. ${m}`); }
    const left = givePlayer(st, g, q);
    if (left > 0) { const b = nearBase(st); if (b) add(b.stock, g, left); }
    return R_(true, `${cap(c.nome)}${q > 1 ? ' ×' + q : ''}: ${L(pr)}.${left > 0 ? ' Non ti sta addosso: lo lasci in base.' : ''}`);
  }
  function sell(st, k, g, q) {
    const E = Ec.eco(st), Sh = E.shops[k], p = p_(st), b = inv(st); if (!Sh) return R_(false, 'Qui non comprano.');
    q = Math.max(1, Math.min(Math.floor(q || 1), cnt(b, g))); if (!q) return R_(false, 'Non ce l\'hai.');
    if (!Sh.sells[g] && !(Sh.black && (CAT[g].ill || CAT[g].prezzo >= 6))) return R_(false, '«Questa roba non la tratto.»');
    const pr = r1(sellPrice(st, Sh, g) * q), cash = tillOf(st, Sh); if (cash < pr) return R_(false, `«In cassa ho ${L(Math.floor(cash))}. Ripassa.»`);
    sub(b, g, q); Sh.stock[g] = (Sh.stock[g] || 0) + q; tillMove(st, Sh, -pr); p.money += pr;
    if (So && st.soldi) { const M = st.soldi; M.player.mov.unshift([st.t, pr, `venduto ${nm(g)} (${Sh.label})`]); }
    if (CAT[g].ill && !Sh.black) suspicious(st, .5, `ha venduto ${nm(g)}`);
    return R_(true, `Vendi ${nm(g)}${q > 1 ? ' ×' + q : ''} per ${L(pr)}.`);
  }
  // lo scambio con le persone: si mette sul piatto roba e soldi; accetta se gli conviene, e se si fida di te un po' meno di quanto conviene
  function npcBag(n) { const P = n.pop; if (!P) return {}; P.inv = P.inv || {}; return P.inv; }
  function valueOf(id, q, who) { const c = CAT[id]; if (!c) return 0; let v = c.prezzo || (c.res ? 3 : .5); if (who && who.pop) { const need = who.pop.need || {}; if (c.eat && c.eat.fame && (need.fame || 0) > .5) v *= 1.5; if (c.ill && who.ris && who.ris.ideo > .6) v *= 1.3; if (c.ill && who.ris && who.ris.ideo < .3) v *= .3; } return v * q; }
  function barterView(st, id) {
    const n = G.byId(st, id); if (!n || n.dead || !n.pop) return null; const nb = npcBag(n), b = inv(st), o = n.op || {};
    return { id: n.id, name: n.name, first: n.first, job: n.pop.job ? n.pop.job.title : '', money: Math.floor(n.pop.money || 0), mood: r1((o.trust || 0) - (o.grudge || 0) - (o.fear || 0) * .5),
      theirs: Object.keys(nb).filter(k => CAT[k] && cnt(nb, k) > 0 && !CAT[k].wpn).map(k => ({ id: k, nome: nm(k), q: cnt(nb, k), v: r1(valueOf(k, 1, null)) })),
      mine: Object.keys(b).filter(k => CAT[k] && cnt(b, k) > 0).map(k => ({ id: k, nome: nm(k), q: cnt(b, k), v: r1(valueOf(k, 1, n)) })), wallet: Math.floor(st.player.money) };
  }
  function barter(st, id, offer) {
    const n = G.byId(st, id); if (!n || n.dead || !n.pop) return R_(false, 'Non c\'è nessuno.');
    const p = p_(st), b = inv(st), nb = npcBag(n), give = offer.give || {}, get = offer.get || {}, myLire = Math.max(0, +offer.lire || 0), theirLire = Math.max(0, +offer.theirLire || 0);
    for (const [k, q] of Object.entries(give)) if (cnt(b, k) < q) return R_(false, `Non hai ${nm(k)} ×${q}.`);
    for (const [k, q] of Object.entries(get)) if (cnt(nb, k) < q) return R_(false, `${n.first} non ha ${nm(k)} ×${q}.`);
    if (p.money < myLire) return R_(false, 'Non hai tutti quei soldi.'); if ((n.pop.money || 0) < theirLire) return R_(false, `${n.first} non ha tutti quei soldi.`);
    const vin = Object.entries(give).reduce((s, [k, q]) => s + valueOf(k, q, n), 0) + myLire, vout = Object.entries(get).reduce((s, [k, q]) => s + valueOf(k, q, null), 0) + theirLire;
    const o = n.op || {}, trust = (o.trust || 0) - (o.grudge || 0), greed = (n.tr && n.tr.avid) || .5, want = vout * (1 + greed * .25 - clamp(trust, -.5, .6) * .3);
    if (vout <= 0 && vin <= 0) return R_(false, 'Non c\'è niente sul piatto.');
    const ill = Object.keys(give).concat(Object.keys(get)).some(k => CAT[k] && CAT[k].ill);
    if (ill && n.tr && n.tr.legge > .75 && trust < .3) { I.note(st, n, `${G.PLAYER_NAME} ha cercato di passargli roba che scotta`, 'shady', { w: .6, who: 'player' }); return R_(false, `«Roba così non la voglio vedere. E nemmeno te.»`); }
    if (vin + 1e-6 < want) { const gap = Math.ceil(want - vin); return R_(false, `«Non mi conviene. Mettici almeno ${gap}.000 lire di più.»`, { gap }); }
    Object.entries(give).forEach(([k, q]) => { sub(b, k, q); add(nb, k, q); });
    Object.entries(get).forEach(([k, q]) => { sub(nb, k, q); givePlayer(st, k, q, true); });
    p.money -= myLire; n.pop.money += myLire; n.pop.money -= theirLire; p.money += theirLire;
    if (n.op) n.op.trust = clamp((n.op.trust || 0) + (vin > want * 1.2 ? .05 : .01), -1, 1);
    I.note(st, n, `scambio con ${G.PLAYER_NAME}`, 'good', { w: .3, who: 'player' });
    return R_(true, `${n.first}: «Affare fatto.»`);
  }

  // =====================================================================================================================
  // L'ECONOMIA DEGLI ABITANTI: produrre con le ricette, procurarsi gli ingredienti, comprare quello che serve a casa
  // =====================================================================================================================
  const fill = (E, g) => { const shops = Object.values(E.shops).filter(Sh => Sh.sells[g] && !Sh.black && !Sh.market); if (!shops.length) return 1; return shops.reduce((s, Sh) => s + (Sh.stock[g] || 0), 0) / shops.reduce((s, Sh) => s + Math.max(1, CAT[g] ? CAT[g].q : 5), 0); };
  function storeHas(store, key, q) { return alts(key).find(id => (store.stock[id] || 0) >= q); }
  function canDo(store, rec) { const use = {}; for (const [k, q] of Object.entries(rec.in)) { const h = storeHas(store, k, q); if (!h) return null; use[h] = q; } return use; }
  function produceHour(st) {
    const E = Ec.eco(st), M = S(st);
    st.npcs.forEach(n => {
      const P = n.pop; if (!P || n.dead || !P.job || !P.cur || P.cur.act !== 'lavoro' || n.jailedUntil > st.t) return;
      workHour(st, P.job.base || P.job.title || '', P.job.t, n);
    });
    // anche il protagonista, quando fa il suo turno, produce come gli altri
    const me = st.me; if (me && me.job && me.warp && me.warp.kind === 'lavoro') { const J = me.job, wt = J.bi >= 0 ? I.tB(J.bi) : I.target(J.place); if (wt) workHour(st, J.title, wt, null); }
  }
  function workHour(st, title, wt, n) {
    const E = Ec.eco(st), M = S(st);
    {
      if (!wt) return;
      const jp = JOBPROD.find(([re, , lre]) => re.test(title) && (!lre || lre.test(wt.label || ''))); if (!jp) return;
      const k = I.tkey ? I.tkey(wt) : (wt.k + ':' + (wt.bi !== undefined ? wt.bi : wt.id)), Sh = Ec.shopAt(st, wt);
      const W = E.work[k] = E.work[k] || { k, t: wt, label: wt.label, stock: {} }, store = Sh || W;
      store.recipes = store.recipes || {}; jp[1].forEach(r => { store.recipes[r] = 1; });
      // la ricetta che serve di più: quella dei cui prodotti c'è meno in giro
      const cands = jp[1].map(id => RECIPES[id]).filter(Boolean).map(rec => ({ rec, use: rec.npcOut ? {} : canDo(store, rec), need: Math.min(...Object.keys(rec.npcOut || rec.out).map(g => fill(E, g) + (store.stock[g] || 0) / Math.max(4, (CAT[g] ? CAT[g].q : 5) * 3))) })).filter(x => x.use && x.need < 2.2);
      if (!cands.length) { if (n && rnd() < .05) I.note(st, n, `a ${wt.label} manca la materia prima: si lavora a vuoto`, 'bad', { w: .2, tag: 'scarsita' }); return; }
      cands.sort((a, b) => a.need - b.need); const { rec, use } = cands[Math.random() < .8 ? 0 : Math.floor(rnd() * cands.length)];
      if (rec.npcOut) { Object.entries(rec.npcOut).forEach(([g, q]) => { if ((store.stock[g] || 0) > Math.max(6, (CAT[g] ? CAT[g].q : 5) * 3)) return; const x = q * (.7 + rnd() * .6); store.stock[g] = (store.stock[g] || 0) + x; M.stats.prodotto += x; }); return; }
      // in un'ora si fanno tante «mani» quante ne stanno (almeno una ogni due ore)
      store._prog = store._prog || {}; store._prog[rec.id] = (store._prog[rec.id] || 0) + 60 / rec.min;
      while (store._prog[rec.id] >= 1) {
        const u = canDo(store, rec); if (!u) { store._prog[rec.id] = 0; break; }
        store._prog[rec.id]--; Object.entries(u).forEach(([g, q]) => { store.stock[g] -= q; });
        Object.entries(rec.out).forEach(([g, q]) => { store.stock[g] = (store.stock[g] || 0) + q; M.stats.prodotto += q; }); M.stats.ricette++;
      }
    }
  }
  // gli ingredienti ai laboratori: da chi li produce, dalle botteghe che li vendono (all'ingrosso), e quello che viene da fuori lo porta la nave
  function supply(st) {
    const E = Ec.eco(st), shops = Object.values(E.shops), works = Object.values(E.work);
    shops.concat(works).filter(W => W.recipes).forEach(W => {
      const want = {};
      Object.keys(W.recipes).forEach(r => { const rec = RECIPES[r]; if (!rec || rec.npcOut) return; Object.entries(rec.in).forEach(([key, q]) => { const id = alts(key).find(x => (W.stock[x] || 0) >= q) || alts(key)[0]; want[id] = Math.max(want[id] || 0, q * 3); }); });
      Object.entries(want).forEach(([g, q]) => {
        if ((W.stock[g] || 0) >= q) return;
        const src = works.find(X => X !== W && (X.stock[g] || 0) >= 1 && !(X.recipes && Object.keys(X.recipes).some(r => RECIPES[r] && Object.keys(RECIPES[r].in).some(k => alts(k).includes(g)))))
          || shops.filter(X => X !== W && X.sells[g] && !X.black && !X.market && (X.stock[g] || 0) > Math.max(1, (CAT[g] ? CAT[g].q : 5) * .3)).sort((a, b) => b.stock[g] - a.stock[g])[0];
        if (!src) { W.missing = W.missing || {}; W.missing[g] = st.t; return; }
        const x = Math.min(q - (W.stock[g] || 0), Math.floor(src.stock[g] * (src.sells ? .5 : 1)) || 1); if (x < 1) return;
        src.stock[g] -= x; W.stock[g] = (W.stock[g] || 0) + x;
        if (Ec.HOOK.wholesale && W.t && src.t) Ec.HOOK.wholesale(st, src, W, g, x);
      });
    });
  }
  // la nave porta anche le materie prime ai laboratori (ferro, latta, carbone, stoffa, lievito…): le paga il laboratorio
  function shipInputs(st, share) {
    const E = Ec.eco(st), bought = {};
    Object.values(E.shops).concat(Object.values(E.work)).filter(W => W.recipes && !W.black).forEach(W => {
      (W.missing ? Object.keys(W.missing) : []).concat(Object.keys(W.recipes).flatMap(r => RECIPES[r] ? Object.keys(RECIPES[r].in).map(k => alts(k)[0]) : [])).forEach(g => {
        if (!CAT[g] || !(CAT[g].imp || ['carbone', 'ferro', 'latta', 'stoffa', 'farina', 'lievito', 'bottoni', 'lana', 'olio', 'sale', 'zucchero', 'uova', 'capi', 'rottami', 'legno', 'bottiglia_vuota', 'barattolo', 'passata', 'pomodori'].includes(g))) return;
        const q = Math.round(Math.max(0, 8 - (W.stock[g] || 0)) * share); if (q < 1) return;
        W.stock[g] = (W.stock[g] || 0) + q; if (W.missing) delete W.missing[g];
        bought[W.k] = (bought[W.k] || 0) + q * CAT[g].prezzo;
      });
    });
    if (Ec.HOOK.ship) Ec.HOOK.ship(st, bought, share);
  }
  // quello che una casa compra oltre al mangiare: legna e carbone (è inverno), sapone, candele, pile, ogni tanto vestiti e attrezzi
  const DEMAND = [['legna', .4], ['carbone', .25], ['sapone', .12], ['candele', .1], ['fiammiferi', .1], ['pile', .05], ['lampadine', .04], ['acqua', .25], ['vestiti', .015], ['maglione', .01], ['scarpe', .008], ['medicine', .03],
    ['detersivo', .05], ['caffe', .1], ['sigarette', .15], ['giornale', .2], ['vino', .15], ['olio', .08], ['sale', .04], ['zucchero', .05], ['bombola', .02], ['coperta', .01]];
  const TOOLJOB = [[/braccian|vignaiol/, 'pala'], [/boscaiol/, 'ascia'], [/carpent|falegnam/, 'sega'], [/fabbr/, 'martello'], [/sart/, 'ago_filo'], [/pescator/, 'canna'], [/cavator|minator/, 'piccone'], [/meccanic/, 'chiave_inglese']];
  function householdDay(st) {
    const E = Ec.eco(st), shops = Object.values(E.shops).filter(Sh => !Sh.black && !Sh.market);
    const seen = new Set();
    st.npcs.forEach(n => {
      const P = n.pop; if (!P || n.dead || !P.homeT || n.jailedUntil > st.t || (P.money || 0) < 4 || P.age < 16) return;
      const hk = I.tkey(P.homeT); if (seen.has(hk)) return; seen.add(hk);   // una spesa per casa
      const list = DEMAND.filter(([g, pr]) => rnd() < pr * (P.money > 40 ? 1.2 : .7)).map(([g]) => g);
      const job = (P.job && (P.job.base || P.job.title)) || ''; const tj = TOOLJOB.find(([re]) => re.test(job)); if (tj && rnd() < .015) list.push(tj[1]);
      list.slice(0, 3).forEach(g => {
        const Sh = shops.filter(X => X.sells[g] && (X.stock[g] || 0) >= 1).sort((a, b) => dist(a.t.x, a.t.y, P.homeT.x, P.homeT.y) - dist(b.t.x, b.t.y, P.homeT.x, P.homeT.y))[0];
        if (!Sh) { E.missing[g] = (E.missing[g] || 0) + 1; if (rnd() < .2) I.note(st, n, `non si trova ${nm(g)} da nessuna parte`, 'bad', { w: .2, tag: 'scarsita' }); return; }
        const pr = Ec.buy(st, n, Sh.t, g, 1); if (pr === null) return;
        P.casa = P.casa || {}; P.casa[g] = (P.casa[g] || 0) + 1; S(st).stats.consumi++;
        // la legna e il carbone si bruciano, il sapone si consuma: in casa non si accumula all'infinito
        Object.keys(P.casa).forEach(k => { if (CAT[k] && (CAT[k].heat || CAT[k].eat) && P.casa[k] > 3) P.casa[k] = 3; });
      });
    });
  }
  // all'inizio i laboratori hanno un magazzino: due giri di ogni ricetta
  function prime(st) {
    const E = Ec.eco(st), M = S(st); if (M.primed) return; M.primed = true;
    st.npcs.forEach(n => {
      const P = n.pop; if (!P || !P.job || !P.job.t) return; const jp = JOBPROD.find(([re, , lre]) => re.test(P.job.base || P.job.title || '') && (!lre || lre.test(P.job.t.label || ''))); if (!jp) return;
      const wt = P.job.t, k = I.tkey ? I.tkey(wt) : wt.label, Sh = Ec.shopAt(st, wt), W = E.work[k] = E.work[k] || { k, t: wt, label: wt.label, stock: {} }, store = Sh || W;
      store.recipes = store.recipes || {}; jp[1].forEach(r => { store.recipes[r] = 1; const rec = RECIPES[r]; if (!rec || rec.npcOut) return; Object.entries(rec.in).forEach(([key, q]) => { const g = alts(key)[0]; store.stock[g] = Math.max(store.stock[g] || 0, q * 3); }); });
    });
    // le persone hanno qualcosa in tasca e in casa (quello che si trova frugando e scambiando)
    st.npcs.forEach(n => { const P = n.pop; if (!P) return; P.inv = P.inv || {}; const job = (P.job && (P.job.base || P.job.title)) || '';
      if (rnd() < .5) P.inv.sigarette = (P.inv.sigarette || 0) + 1; if (rnd() < .3) P.inv.fiammiferi = 1; if (rnd() < .2) P.inv.pane = 1; if (rnd() < .15) P.inv.accendino = 1;
      const tj = TOOLJOB.find(([re]) => re.test(job)); if (tj && rnd() < .6) P.inv[tj[1]] = 1;
      if (/pescator/.test(job)) P.inv.sarde = 2; if (/fornai/.test(job)) P.inv.pane = 3; if (/allevator/.test(job)) { P.inv.uova = 1; P.inv.lana = 1; } if (/farmacist|infermier|medic/.test(job)) { P.inv.bende = 2; P.inv.medicine = 1; }
      if (/tipograf/.test(job)) { P.inv.carta = 1; P.inv.inchiostro = 1; } if (/saldator|meccanic/.test(job)) { P.inv.nastro = 1; P.inv.cavo = 1; }
      if (P.giro === 'ricettatore') { P.inv.orologio = 1; P.inv.radiolina = 1; P.inv.grimaldello = 1; } if (P.giro === 'trafficante') { P.inv.sigarette_contr = 3; P.inv.whisky = 1; } if (P.giro === 'ladro') P.inv.grimaldello = 1;
      if (n.cop) { P.inv.manette = 1; P.inv.gallette = 1; } });
  }

  // =====================================================================================================================
  // I PONTI CON GLI ALTRI MODULI
  // =====================================================================================================================
  const GENERE = { cibo: 'cibo', bevande: 'cibo', dispensa: 'cibo', combustibili: 'materia', edilizia: 'materia', rottami: 'materia', attrezzi: 'attrezzo', armi: 'attrezzo', valori: 'vizio', stampa: 'casa' };
  (function bridgeEconomy() {
    // le merci dell'economia diventano gli oggetti del catalogo (stessi id dove c'erano già)
    Object.keys(Ec.MERCI).forEach(k => { if (!CAT[k]) delete Ec.MERCI[k]; });
    Object.values(CAT).forEach(c => { Ec.MERCI[c.id] = [c.nome, c.prezzo || 1, c.ill ? 'clandestino' : (GENERE[c.cat] || 'casa'), c.q || 5]; });
    Ec.MERCI.poster[2] = 'clandestino'; Ec.MERCI.libretto[2] = 'clandestino';
    Ec.IMPORT.length = 0; IMPORT.forEach(g => Ec.IMPORT.push(g));
    Ec.SELL.length = 0; SHOPLIST.forEach(([ref, goods]) => { if (ref.startsWith('use:') ? G.BUILDINGS.some(b => b.use === ref.slice(4)) : PLACES[ref]) Ec.SELL.push([ref, goods.filter(g => CAT[g])]); });
    Ec.PROD.length = 0;   // la produzione la fanno le ricette (produceHour qui sotto)
  })();
  (function bridgeActions() {
    // le tasche: ogni oggetto del catalogo si può tenere in tasca (Azioni.ITEMS lo conosce), senza azioni «compra» sparse in giro
    Object.values(CAT).forEach(c => { if (!Az.ITEMS[c.id]) Az.ITEMS[c.id] = { id: c.id, name: c.nome, stuff: !c.tool }; else Az.ITEMS[c.id].name = Az.ITEMS[c.id].name || c.nome; });
    Object.assign(G.SEV, { furto: .45 }); Object.assign(G.NOISE, { furto: 4 }); Object.assign(G.NEG, { furto: 1 }); Object.assign(G.LABEL, { furto: 'Furto' });
  })();
  (function bridgeRisacca() {
    const X = RS.EXT;
    // le risorse astratte diventano categorie: «materiali» = assi, lamiere, mattoni…; quelle che sono già un oggetto (carta, benzina) restano se stesse
    Object.values(CAT).forEach(c => { if (!RS.RES[c.id]) RS.RES[c.id] = { name: c.nome, one: c.nome, cat: GROUPS[c.cat], syn: [c.nome], item: true }; });
    const val = (bag, res) => { if (!bag) return 0; if (RESOF[res]) return RESOF[res].reduce((s, [id, k]) => s + cnt(bag, id) * k, 0) + (CAT[res] || !bag[res] ? 0 : bag[res]); return cnt(bag, res); };
    const bags = (st, prefer) => { const out = []; if (prefer) out.push(prefer.stock); st.ris.bases.filter(b => b.alive && b !== prefer).forEach(b => out.push(b.stock)); out.push(st.ris.inv); if (st.player && st.player.inv) out.push(st.player.inv); return out; };
    X.resTotal = (st, res) => bags(st).reduce((s, b) => s + val(b, res), 0);
    // si prende il necessario partendo dagli oggetti che valgono meno per quella categoria
    X.resTake = (st, res, qty, prefer) => {
      if (X.resTotal(st, res) < qty - 1e-6) return false; let need = qty;
      for (const bag of bags(st, prefer)) {
        if (!RESOF[res]) { const k = Math.min(need, bag[res] || 0); if (k > 0) { sub(bag, res, k); need -= k; } }
        else { if (bag[res] && !CAT[res]) { const k = Math.min(need, bag[res]); sub(bag, res, k); need -= k; }
          RESOF[res].slice().sort((a, b) => (CAT[a[0]].prezzo / a[1]) - (CAT[b[0]].prezzo / b[1])).forEach(([id, k]) => { while (need > 1e-6 && cnt(bag, id) > 0) { sub(bag, id, 1); need -= k; } }); }
        if (need <= 1e-6) break;
      }
      return true;
    };
    // quello che arriva in astratto (un furto di «materiali», una spesa di «viveri») diventa roba vera
    const MIX = { materiali: ['assi', 'assi', 'lamiera', 'chiodi', 'travi', 'tubi', 'rete'], viveri: ['scatolame', 'pasta', 'pane', 'legumi', 'gallette', 'carne_scatola'], attrezzi: ['martello', 'cacciavite', 'pinze', 'piede', 'tronchesi'],
      radio: ['valvole', 'cavo', 'transistor', 'pile', 'stagno'], medicine: ['medicine', 'bende', 'garze', 'disinfettante'], mobili: ['branda', 'materasso', 'sedia', 'tavolo', 'coperta'], vernice: ['bomboletta', 'vernice'], merce: ['sigarette_contr', 'merce'] };
    X.concrete = (res, qty) => {
      if (CAT[res] && !MIX[res]) return { [res]: qty };
      const L0 = MIX[res]; if (!L0) return { [res]: qty }; const out = {}; let v = 0, i = 0;
      while (v < qty - 1e-6 && i++ < 60) { const id = pick(L0); out[id] = (out[id] || 0) + 1; v += CAT[id].resV || 1; }
      return out;
    };
    X.buildCost = (kind, id) => (BUILD[kind] && BUILD[kind][id]) || null;
    X.buildMiss = (st, cost, prefer) => { const P = bags(st, prefer); return Object.entries(cost).filter(([key, q]) => !alts(key).some(id => P.reduce((s, b) => s + cnt(b, id), 0) >= q)).map(([key, q]) => `${alts(key).map(nm).join(' o ')} ×${q}`); };
    X.buildTake = (st, cost, prefer) => { const P = bags(st, prefer); Object.entries(cost).forEach(([key, q]) => { const id = alts(key).find(x => P.reduce((s, b) => s + cnt(b, x), 0) >= q); if (id) poolTake(P, id, q); }); };
    X.labIn = { stamperia: { carta: 1, inchiostro: 1 }, falsari: { carta_bollata: 1, foto_tessera: 1 }, officina: { nastro: 1, pile: 1, cavo: 1, zucchero: 1 } };
    X.labOut = { stamperia: { volantini: 1 }, falsari: { documenti: 1 }, officina: { kit: 1 } };
    X.itemName = id => nm(id);
  })();
  (function bridgeInteriors() {
    const X = INT.EXTRA; if (!X) return;
    // le stanze dei mestieri: la forgia del fabbro, il laboratorio del falegname, il macello, l'officina, il retro del negozio di radio
    Object.assign(X.names, {
      fabbro: [['forgia', 'magazzino', 'retro', 'bagno'], ['camera', 'soggiorno', 'bagno', 'cucina']], falegnameria: [['laboratorio', 'magazzino', 'retro', 'bagno'], ['camera', 'soggiorno', 'bagno', 'cucina']],
      macelleria: [['macelleria', 'macello', 'cella_frigo', 'bagno'], ['camera', 'soggiorno', 'bagno', 'cucina']], emporio: [['emporio', 'magazzino', 'ufficio', 'bagno'], ['magazzino', 'ufficio', 'archivio', 'bagno']],
      fruttivendolo: [['bottega', 'magazzino', 'retro', 'bagno'], ['camera', 'soggiorno', 'bagno', 'cucina']], video: [['bottega', 'radio_r', 'magazzino', 'bagno'], ['camera', 'soggiorno', 'bagno', 'cucina']], cantina: [['cantina_r', 'magazzino', 'retro', 'bagno'], ['camera', 'soggiorno', 'bagno', 'cucina']],
    });
    Object.assign(X.fur, {
      forgia: ['st_forgia', 'st_saldatrice', 'pv_banco_lavoro', 'st_cassetta', 'fx_box-small', 'cardboardBoxClosed', 'kitchenBar', 'ar_cash-register'],
      laboratorio: ['st_banco_falegname', 'st_banco_falegname', 'pv_banco_lavoro', 'st_cassetta', 'cardboardBoxClosed', 'kitchenBar', 'ar_cash-register'],
      macelleria: ['st_banco_macellaio', 'kitchenBar', 'kitchenBar', 'ar_cash-register', 'kitchenFridge'], macello: ['st_banco_macellaio', 'kitchenSink', 'kitchenFridge', 'trashcan'],
      emporio: ['kitchenBar', 'kitchenBar', 'ar_cash-register', 'bookcaseOpen', 'bookcaseOpen', 'bookcaseOpen', 'bookcaseOpenLow', 'bookcaseOpenLow', 'pottedPlant'],
radio_r: ['st_banco_radio', 'st_cassetta', 'cardboardBoxClosed', 'desk', 'chairDesk'],
      cantina_r: ['fd_barrel', 'fd_barrel', 'fd_barrel', 'fd_barrel', 'kitchenBar', 'ar_cash-register'],
    });
    // le postazioni nelle stanze che c'erano già (in testa: si piazzano per prime)
    X.pre = { forno: ['st_forno'], panetteria: ['st_forno'], retro: ['st_cassetta'], visite: ['st_tavolo_medico'], farmacia: ['st_tavolo_medico'], deposito: ['st_cassetta'], officina: ['st_saldatrice', 'st_cassetta'], armeria: ['st_rastrelliera', 'st_rastrelliera'],
      caveau: ['st_cassaforte', 'st_cassaforte'], sportelli: ['st_cassaforte'], tipografia: ['st_ciclostile'], sartoria: ['st_macchina_cucire', 'st_macchina_cucire'], reparto: ['st_cassetta'], ufficio: ['st_cassaforte'], ripostiglio: ['st_cassetta'] };
    Object.assign(X.sz, { st_forno: [1.6, 1.2, 1], st_forgia: [1.4, 1, 1], st_saldatrice: [.8, .6, 1], st_banco_lavoro: [1.8, .8, 1], st_banco_falegname: [2, .8, 1], st_banco_macellaio: [1.6, .8, 1], st_macchina_cucire: [1, .6, 1],
      st_ciclostile: [1, .7, 1], st_banco_radio: [1.4, .7, 1], st_camera_oscura: [1.4, .7, 1], st_tavolo_medico: [1.9, .8, 1], st_alambicco: [.9, .9, 1], st_stufa: [.8, .8, 1], st_cassetta: [.6, .35, 0], st_cassaforte: [.8, .7, 1], st_rastrelliera: [1.4, .5, 1] });
    X.kind = b => b.id === 'video' ? 'video' : b.id === 'cantina' ? 'cantina' : null;
  })();

  // =====================================================================================================================
  // LE AZIONI DEL GIOCATORE (QUI, ADESSO)
  // =====================================================================================================================
  function here(st) {
    const p = p_(st), out = [], add0 = (id, label, arg, panel, bad) => out.push({ id: 'og_' + id, label, arg: arg === undefined ? null : arg, panel, bad: !!bad });
    if (st.over || p.vehicle) return out;
    containersHere(st).forEach(c => add0('fruga', c.locked ? `Forza: ${c.label}` : `Fruga: ${c.label}`, c.ref, 'fruga', c.locked));
    const sts = stationsHere(st); if (sts.size || nearBase(st)) add0('lavora', `Lavora qui (${[...sts].map(s => STATIONS[s] ? STATIONS[s].nome : s).join(', ') || 'a mano'})`, null, 'lavora');
    const ex = Object.values(RECIPES).filter(r => r.place && placeOk(st, r)); if (ex.length) add0('lavora', ex.map(r => cap(r.nome)).join(' · '), null, 'lavora');
    const n = st.npcs.filter(k => !k.dead && k.pop && !k.inside && !k.aggro && !(k.cop && G.wantedLevel(st) > 0) && dist(k.x, k.y, p.x, p.y) < 2.6).sort((a, b) => dist(a.x, a.y, p.x, p.y) - dist(b.x, b.y, p.x, p.y))[0];
    if (n && !p.indoor) add0('scambia', `Scambia con ${n.first}`, n.id, 'scambia');
    return out;
  }
  function act(st, id, arg, ex) {
    ex = ex || {}; const k = String(id).replace(/^og_/, '');
    switch (k) {
      case 'compra': return buy(st, arg, ex.g, ex.q, ex.mode);
      case 'vendi': return sell(st, arg, ex.g, ex.q);
      case 'fai': return craft(st, arg, ex.q);
      case 'usa': return consume(st, arg);
      case 'butta': { const b = inv(st), q = Math.min(ex.q || 1, cnt(b, arg)); if (!q) return R_(false, 'Non ce l\'hai.'); sub(b, arg, q); const B = nearBase(st); if (B) { add(B.stock, arg, q); return R_(true, `Lasci ${nm(arg)}${q > 1 ? ' ×' + q : ''} in ${B.name}.`); } return R_(true, `Butti ${nm(arg)}.`); }
      case 'deposita': { const B = nearBase(st); if (!B) return R_(false, 'Qui non c\'è una base.'); const b = inv(st), list = arg === '*' ? Object.keys(b).filter(x => !CAT[x] || !CAT[x].tool) : [arg]; let n0 = 0; list.forEach(g => { const q = arg === '*' ? cnt(b, g) : Math.min(ex.q || 1, cnt(b, g)); if (q > 0) { sub(b, g, q); add(B.stock, g, q); n0 += q; } }); return R_(!!n0, n0 ? `Lasciati ${n0} oggetti in ${B.name}.` : 'Non hai niente da lasciare.'); }
      case 'preleva': { const B = nearBase(st); if (!B) return R_(false, 'Qui non c\'è una base.'); const q = Math.min(ex.q || 1, cnt(B.stock, arg)); if (!q) return R_(false, 'In base non c\'è.'); sub(B.stock, arg, q); const left = givePlayer(st, arg, q); if (left) add(B.stock, arg, left); return R_(q > left, q > left ? `Prendi ${nm(arg)}${q - left > 1 ? ' ×' + (q - left) : ''}.` : 'Non ti sta addosso.'); }
      case 'apri': { const C = contByRef(st, arg); if (!C) return R_(false, 'Non c\'è niente da frugare qui.'); return openC(st, C); }
      case 'prendi': { const C = contByRef(st, arg); if (!C) return R_(false, 'Non c\'è niente da frugare qui.'); if (C.locked) return R_(false, 'È chiuso.'); return takeFrom(st, C, ex.g, ex.q); }
      case 'prendi_tutto': { const C = contByRef(st, arg); if (!C || C.locked) return R_(false, 'Non si può.'); const msgs = []; for (const v of contView(st, C).filter(v => v.src !== 'shop' || ex.shop)) { const r = takeFrom(st, C, v.id, v.q); if (r.ok) msgs.push(r.msg); if (/ti ha visto/.test(r.msg)) break; } return R_(!!msgs.length, msgs.join(' ') || 'Non ti sta più niente addosso.'); }
      case 'posa': { const C = contByRef(st, arg); if (!C) return R_(false, 'Non qui.'); return putInto(st, C, ex.g, ex.q); }
      case 'scambia': return barter(st, arg, ex);
      default: return R_(false, 'Non si può.');
    }
  }
  const R_ = (ok, msg, x) => Object.assign({ ok, msg: msg || '' }, x || {});
  const openUI = (panel, arg) => { if (typeof OggettiUI !== 'undefined') OggettiUI.open(panel, arg); };
  (function hookUI() {
    const h0 = RS.here, a0 = RS.playerAct;
    RS.here = st => { const o = h0(st) || []; try { return o.concat(here(st).map(a => ({ id: a.id, label: a.label, arg: a.arg, bad: a.bad }))); } catch (e) { return o; } };
    RS.playerAct = (st, id, arg, extra) => {
      if (!String(id).startsWith('og_')) return a0(st, id, arg, extra);
      const l = here(st), a = l.find(x => x.id === id && x.arg === arg) || l.find(x => x.id === id);
      if (a && a.panel) { openUI(a.panel, arg); return { ok: true, msg: '' }; }
      return act(st, id, arg, extra);
    };
    const pa0 = Az.playerActions;
    Az.playerActions = function (st) {
      const o = (pa0.apply(this, arguments) || []).filter(a => !/^compra_|^prendi_(pala|carriola)$/.test(a.id || ''));
      try { here(st).forEach(a => o.push({ id: a.id, label: a.label, off: '', run: () => { openUI(a.panel, a.arg); return ''; } })); } catch (e) { }
      return o;
    };
    // le Tasche mostrano tutto il catalogo: anche la roba (non solo gli attrezzi)
    const pi0 = Az.playerItems;
    Az.playerItems = function (st) { const l = pi0.apply(this, arguments) || []; l.forEach(x => { if (CAT[x.id]) { x.cat = CAT[x.id].cat; x.peso = CAT[x.id].peso; x.eat = !!CAT[x.id].eat; } }); return l; };
  })();

  // =====================================================================================================================
  // IL TEMPO
  // =====================================================================================================================
  function hourly(st, h, wd) {
    if (!S(st).primed) prime(st);
    produceHour(st);
    if (h % 2 === 0) supply(st);
    if (h === 17) householdDay(st);
    if ((wd === 0 || wd === 3) && h === 6) { const E = Ec.eco(st); shipInputs(st, E.blocked ? 0 : 1); }
    thirstTick(st, 1);
    const M = S(st); if (M.calore) M.calore = clamp(M.calore - .08, 0, 1);
  }
  function install() {
    const H = G.HOOKS; if (H.__oggetti) return; H.__oggetti = true;
    const s0 = H.step;
    H.step = (st, dt) => {
      if (s0) s0(st, dt);
      if (!st.pop) return;
      const M = S(st), hm = Math.floor(st.t / 60);
      if (M.hour !== hm) { M.hour = hm; hourly(st, hm % 24, Po.weekday(st.t)); }
      if (!(M._lk > st.clock - 1)) { M._lk = st.clock || 0; const w = weightOf(inv(st)), c = capacity(st); st.player.loadK = w <= c ? 1 : clamp(1 - (w - c) / (c * 1.5), .35, 1); }
    };
  }
  install();

  // =====================================================================================================================
  // PER IL PANNELLO E PER LE PROVE
  // =====================================================================================================================
  function pocketsView(st) {
    const b = inv(st), W = S(st).wear;
    return { peso: r1(weightOf(b)), cap: capacity(st), money: Math.floor(st.player.money), sete: st.me && st.me.need ? r1(st.me.need.sete || 0) : 0, fame: st.me && st.me.need ? r1(st.me.need.fame || 0) : 0,
      items: Object.keys(b).filter(k => cnt(b, k) > 0).map(k => { const c = CAT[k] || { nome: k, cat: 'altro', peso: .5 }; return { id: k, nome: c.nome, cat: c.cat, catLabel: GROUPS[c.cat] || 'Altro', q: cnt(b, k), peso: c.peso, eat: !!c.eat, tool: c.tool ? Math.round(100 * (W[k] === undefined ? c.tool : W[k]) / c.tool) : null, ill: !!c.ill, st: c.st || null }; }).sort((a, b) => a.cat.localeCompare(b.cat) || a.nome.localeCompare(b.nome)),
      base: nearBase(st) ? { name: nearBase(st).name, items: Object.keys(nearBase(st).stock).filter(k => cnt(nearBase(st).stock, k) > 0).map(k => ({ id: k, nome: nm(k), q: cnt(nearBase(st).stock, k) })) } : null };
  }
  function frugaView(st, ref) { const C = contByRef(st, ref); if (!C) return null; return { ref, label: C.label, locked: C.locked, need: C.locked ? alts(LOCKED[C.fid]).map(nm).join(' o ') : '', items: C.locked ? [] : contView(st, C), mine: pocketsView(st) }; }
  function report(st) {
    const E = Ec.eco(st), M = S(st), shops = Object.values(E.shops);
    const empty = []; shops.forEach(Sh => Object.keys(Sh.sells).forEach(g => { if (!Sh.market && (Sh.stock[g] || 0) < 1) empty.push(`${nm(g)} (${Sh.label})`); }));
    const work = Object.values(E.work).concat(shops).filter(W => W.recipes).map(W => `${W.label}: ${Object.entries(W.stock).filter(([, v]) => v >= 1).map(([g, v]) => `${nm(g)} ${Math.floor(v)}`).slice(0, 6).join(', ')}${W.missing && Object.keys(W.missing).length ? ` — manca ${Object.keys(W.missing).map(nm).join(', ')}` : ''}`);
    return { stats: M.stats, vuoti: empty.length, esempiVuoti: empty.slice(0, 12), laboratori: work, mancanze: E.missing };
  }
  return { CAT, GROUPS, RECIPES, STATIONS, FURN2ST, SHOPLIST, LOOT, ROOM_LOOT, SPOT_LOOT, BUILD, JOBPROD, S, nm, inv, givePlayer, weightOf, capacity, stationsHere, containersHere, recipesView, craft, consume,
    counter, buy, sell, barterView, barter, frugaView, contByRef, pocketsView, here, act, report, produceHour, supply, householdDay, prime };
})();
if (typeof module !== 'undefined') module.exports = Oggetti;
